# Replit.md - WMS Multi-Tenant System

## Overview

This is a Multi-Tenant Warehouse Management System (WMS) built with a modern full-stack architecture. The application uses Express.js for the backend API, React with TypeScript for the frontend, and PostgreSQL with Drizzle ORM for data persistence. The system is designed to support multiple tenants with isolated data and user management capabilities.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **UI Components**: Radix UI with shadcn/ui design system
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: React Context API for auth and tenant management
- **Data Fetching**: TanStack Query (React Query) for server state management
- **Build Tool**: Vite with hot module replacement

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ESM modules
- **API Pattern**: RESTful API with structured route handlers
- **Database**: PostgreSQL with Drizzle ORM
- **Schema**: Shared type definitions between client and server
- **Session Management**: Express sessions with PostgreSQL store

### Data Storage Solutions
- **Primary Database**: PostgreSQL via Neon Database (@neondatabase/serverless)
- **ORM**: Drizzle ORM with TypeScript-first approach
- **Migrations**: Drizzle Kit for schema management
- **Connection**: Serverless-compatible database connections

## Key Components

### Multi-Tenant Architecture
- **Tenant Isolation**: Row-level security with tenant_id foreign keys
- **User Management**: Role-based access control (user, manager, admin, superadmin)
- **Dynamic Tenant Selection**: Context-based tenant switching in UI
- **Domain-based Tenancy**: Each tenant has a unique domain identifier

### Authentication and Authorization
- **Session-based Auth**: Server-side session management
- **RBAC System**: Permission-based access control with MANAGE/VIEW/NO_ACCESS levels
- **Permission Matrix**: Comprehensive role-to-resource mapping system
- **Protected Routes**: Route-level access control with ProtectedRoute component
- **Component-level Security**: PermissionGate for conditional UI rendering
- **Tenant Scoping**: All operations scoped to current tenant context

### Database Schema
- **Core Entities**: tenants, users, products, orders, inventory, warehouse_locations
- **Relationships**: Proper foreign key constraints with cascading
- **Audit Fields**: Created/updated timestamps on all entities
- **JSON Storage**: Flexible metadata storage using JSONB fields

### UI/UX Design
- **Design System**: shadcn/ui components with consistent styling
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Internationalization**: Multi-language support (English, Bahasa Indonesia)
- **Dark Mode**: Theme switching capability built-in
- **Accessibility**: WCAG-compliant components from Radix UI

## Data Flow

1. **Request Flow**: Client → Express Routes → Storage Layer → Database
2. **Authentication**: Session validation on protected routes
3. **Tenant Context**: Current tenant propagated through request context
4. **Data Queries**: TanStack Query manages client-side caching and synchronization
5. **Real-time Updates**: Optimistic updates with background synchronization

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless connection
- **drizzle-orm**: Type-safe ORM with PostgreSQL dialect
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI component primitives
- **wouter**: Lightweight client-side routing
- **zod**: Runtime type validation and schema definition

### Development Tools
- **Vite**: Build tool with hot reload and optimized bundling
- **TypeScript**: Type safety across the entire stack
- **Tailwind CSS**: Utility-first CSS framework
- **ESLint/Prettier**: Code quality and formatting

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds static assets to `dist/public`
- **Backend**: ESBuild bundles server code to `dist/index.js`
- **Assets**: Static files served by Express in production

### Environment Configuration
- **Database**: PostgreSQL connection via DATABASE_URL environment variable
- **Development**: Hot reload with Vite dev server proxy
- **Production**: Single Express server serving both API and static files

### Scalability Considerations
- **Serverless-ready**: Database connections optimized for serverless deployment
- **Stateless Design**: No server-side state beyond database sessions
- **CDN-friendly**: Static assets can be served from CDN

## Changelog

- June 30, 2025. Phase 1: Initial multi-tenant WMS foundation with Express backend and React frontend
- June 30, 2025. Phase 2: UI/UX foundation with dark blue sidebar (#1E3A8A), role-based navigation, and internationalization
- June 30, 2025. Phase 3: Comprehensive RBAC implementation with permission-based access control system
- June 30, 2025. Phase 4: Authentication and multi-tenancy foundation with mock login system, protected routes, and localStorage persistence
- June 30, 2025. Phase 5: Mock Data Layer and Master Data Configuration - Implemented editable inventory master with full CRUD operations, data persistence layer with localStorage, inventory types and package types management, comprehensive form validation and expiry date tracking
- June 30, 2025. Phase 5A: Cleanup and Logical Realignment - Fixed misaligned features, restructured Settings menu with master data management, converted Inventory page to stock viewing only with "Receive Purchase Order" placeholder, added comprehensive placeholder notices with "Coming in Phase 6+" badges across all future features
- June 30, 2025. Phase 5B: Functional Cleanup and Structural Alignment - Implemented comprehensive General Settings with company info, language, and currency options; added functional PO/SO numbering configuration; created complete Customer management with delivery locations; updated Suppliers with unified Lat/Lng input format; completed System section with backup/restore and version info functionality; converted Inventory to stock viewing with bin locations and quantity display
- June 30, 2025. Phase 5C: Final Cleanup Patch - Completed all unresolved functionality: General Settings now load from and persist to localStorage; replaced "Receive Purchase Order" with "Add Inventory Item"; implemented functional backup/restore system with JSON export/import; updated Suppliers with unified Lat/Lng input format; removed Reset Data section; updated version info to Phase 5C status; all settings persist across page reloads
- June 30, 2025. Phase 5D: Final Fix Pass - Implemented functional Inventory Items management with Add/Edit/Delete modals and localStorage persistence; fixed PO/SO numbering independence with separate state management and live preview; created complete Warehouse Layout hierarchy with Zone/Aisle/Shelf/Bin structure; implemented full Integration section with SMTP configuration, Inbound/Outbound API management, and test connection functionality; updated system version to v1.0.0-phase5d with all Phase 5 fixes complete
- June 30, 2025. Phase 5E: Master Data Cleanup & Label Corrections - Enabled "Add Inventory Item" button on main Inventory page with full CRUD functionality; implemented business logic for deletion (only allowed when stock = 0); updated field labels to "Size (m³)" and "Weight (kg)" for clarity; filtered Inventory Type and Package Type dropdowns to show only active items; confirmed all new types default to active=true; completed inventory management with proper stock-based deletion protection
- July 1, 2025. Sprint 5.1F: Inventory & Master Data Behavior Fixes - Removed duplicate "Save Settings" button and disabled language dropdown with tooltip; added Active/Inactive toggle and Status column to inventory items with business logic for deactivation; implemented validation to prevent deactivating inventory/package types while in use by inventory items; enhanced forms with proper active status management and validation messaging
- July 1, 2025. Sprint 5.1H: Warehouse Setup Data Correction + Path-Based Uniqueness Enforcement - Replaced warehouse structure with flattened zones/aisles/shelves/bins format using corrected seed data; implemented path-based uniqueness validation for location IDs (A.1.2.1 format); added comprehensive validation with parent existence checks and child dependency prevention for deletions; enhanced error messaging with clear explanations for failed operations
- July 1, 2025. Sprint 5.1J: Final Warehouse Setup UI Fixes - Fixed duplicate key warnings by enhancing unique key generation; corrected all warehouse field mappings (zone.name, aisle.aisleId, shelf.shelfId, bin.binId); restored missing Add Shelf/Add Bin buttons with proper contextual parameters; improved error messages with specific details ("Zone ID 'A' already exists", "Aisle A.1 already exists"); implemented validation during editing with ID conflict prevention; added "Add First Shelf" and "Add First Bin" buttons for empty containers

## User Preferences

Preferred communication style: Simple, everyday language.