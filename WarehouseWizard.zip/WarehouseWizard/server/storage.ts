import { 
  tenants, users, products, orders, orderItems, inventory, warehouseLocations,
  type Tenant, type InsertTenant,
  type User, type InsertUser,
  type Product, type InsertProduct,
  type Order, type InsertOrder,
  type OrderItem, type Inventory, type InsertInventory,
  type WarehouseLocation
} from "@shared/schema";

export interface IStorage {
  // Tenant operations
  getTenants(): Promise<Tenant[]>;
  getTenant(id: number): Promise<Tenant | undefined>;
  createTenant(tenant: InsertTenant): Promise<Tenant>;
  updateTenant(id: number, tenant: Partial<InsertTenant>): Promise<Tenant | undefined>;

  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUsersByTenant(tenantId: number): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;

  // Product operations
  getProducts(tenantId: number): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;

  // Order operations
  getOrders(tenantId: number): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, order: Partial<InsertOrder>): Promise<Order | undefined>;
  getOrdersByStatus(tenantId: number, status: string): Promise<Order[]>;

  // Inventory operations
  getInventory(tenantId: number): Promise<Inventory[]>;
  getInventoryByProduct(productId: number): Promise<Inventory[]>;
  updateInventory(productId: number, locationCode: string, quantity: number): Promise<Inventory | undefined>;

  // Dashboard metrics
  getDashboardMetrics(tenantId: number): Promise<{
    totalInventory: number;
    pendingOrders: number;
    completedToday: number;
    warehouseCapacity: number;
  }>;

  // Top moving products
  getTopProducts(tenantId: number, limit: number): Promise<{
    product: Product;
    quantity: number;
    trend: string;
  }[]>;
}

export class MemStorage implements IStorage {
  private tenants: Map<number, Tenant> = new Map();
  private users: Map<number, User> = new Map();
  private products: Map<number, Product> = new Map();
  private orders: Map<number, Order> = new Map();
  private orderItems: Map<number, OrderItem> = new Map();
  private inventory: Map<number, Inventory> = new Map();
  private warehouseLocations: Map<number, WarehouseLocation> = new Map();
  
  private currentTenantId = 1;
  private currentUserId = 1;
  private currentProductId = 1;
  private currentOrderId = 1;
  private currentInventoryId = 1;

  constructor() {
    this.seedInitialData();
  }

  private seedInitialData() {
    // Create demo tenant
    const demoTenant: Tenant = {
      id: this.currentTenantId++,
      name: "Acme Corp Warehouse",
      domain: "acme-corp",
      isActive: true,
      settings: null,
      createdAt: new Date(),
    };
    this.tenants.set(demoTenant.id, demoTenant);

    // Create demo user
    const demoUser: User = {
      id: this.currentUserId++,
      tenantId: demoTenant.id,
      username: "johndoe",
      email: "john.doe@acme.com",
      password: "hashed_password",
      role: "manager",
      firstName: "John",
      lastName: "Doe",
      isActive: true,
      createdAt: new Date(),
    };
    this.users.set(demoUser.id, demoUser);

    // Create demo products
    const products = [
      { name: "Wireless Headphones", sku: "WH-001", category: "Electronics", price: "99.99" },
      { name: "Smartphone Case", sku: "SC-045", category: "Accessories", price: "24.99" },
      { name: "Gaming Laptop", sku: "GL-789", category: "Electronics", price: "1299.99" },
    ];

    products.forEach(p => {
      const product: Product = {
        id: this.currentProductId++,
        tenantId: demoTenant.id,
        sku: p.sku,
        name: p.name,
        description: null,
        category: p.category,
        price: p.price,
        weight: null,
        dimensions: null,
        isActive: true,
        createdAt: new Date(),
      };
      this.products.set(product.id, product);
    });

    // Create demo orders
    const orders = [
      { orderNumber: "ORD-001234", customerName: "Sarah Johnson", customerEmail: "sarah.j@email.com", status: "processing", priority: "high" },
      { orderNumber: "ORD-001235", customerName: "Michael Chen", customerEmail: "m.chen@company.com", status: "shipped", priority: "medium" },
      { orderNumber: "ORD-001236", customerName: "Emma Williams", customerEmail: "emma.w@store.net", status: "packed", priority: "low" },
    ];

    orders.forEach(o => {
      const order: Order = {
        id: this.currentOrderId++,
        tenantId: demoTenant.id,
        orderNumber: o.orderNumber,
        customerName: o.customerName,
        customerEmail: o.customerEmail,
        status: o.status,
        priority: o.priority,
        totalItems: Math.floor(Math.random() * 5) + 1,
        totalValue: null,
        shippingAddress: null,
        notes: null,
        createdAt: new Date(Date.now() - Math.random() * 86400000 * 2), // Random date within last 2 days
        updatedAt: new Date(),
      };
      this.orders.set(order.id, order);
    });
  }

  // Tenant operations
  async getTenants(): Promise<Tenant[]> {
    return Array.from(this.tenants.values());
  }

  async getTenant(id: number): Promise<Tenant | undefined> {
    return this.tenants.get(id);
  }

  async createTenant(tenant: InsertTenant): Promise<Tenant> {
    const newTenant: Tenant = {
      ...tenant,
      id: this.currentTenantId++,
      createdAt: new Date(),
    };
    this.tenants.set(newTenant.id, newTenant);
    return newTenant;
  }

  async updateTenant(id: number, tenant: Partial<InsertTenant>): Promise<Tenant | undefined> {
    const existing = this.tenants.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...tenant };
    this.tenants.set(id, updated);
    return updated;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUsersByTenant(tenantId: number): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => user.tenantId === tenantId);
  }

  async createUser(user: InsertUser): Promise<User> {
    const newUser: User = {
      ...user,
      id: this.currentUserId++,
      createdAt: new Date(),
    };
    this.users.set(newUser.id, newUser);
    return newUser;
  }

  async updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined> {
    const existing = this.users.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...user };
    this.users.set(id, updated);
    return updated;
  }

  // Product operations
  async getProducts(tenantId: number): Promise<Product[]> {
    return Array.from(this.products.values()).filter(product => product.tenantId === tenantId);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const newProduct: Product = {
      ...product,
      id: this.currentProductId++,
      createdAt: new Date(),
    };
    this.products.set(newProduct.id, newProduct);
    return newProduct;
  }

  async updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const existing = this.products.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...product };
    this.products.set(id, updated);
    return updated;
  }

  // Order operations
  async getOrders(tenantId: number): Promise<Order[]> {
    return Array.from(this.orders.values())
      .filter(order => order.tenantId === tenantId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const newOrder: Order = {
      ...order,
      id: this.currentOrderId++,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.orders.set(newOrder.id, newOrder);
    return newOrder;
  }

  async updateOrder(id: number, order: Partial<InsertOrder>): Promise<Order | undefined> {
    const existing = this.orders.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...order, updatedAt: new Date() };
    this.orders.set(id, updated);
    return updated;
  }

  async getOrdersByStatus(tenantId: number, status: string): Promise<Order[]> {
    return Array.from(this.orders.values())
      .filter(order => order.tenantId === tenantId && order.status === status);
  }

  // Inventory operations
  async getInventory(tenantId: number): Promise<Inventory[]> {
    return Array.from(this.inventory.values()).filter(inv => inv.tenantId === tenantId);
  }

  async getInventoryByProduct(productId: number): Promise<Inventory[]> {
    return Array.from(this.inventory.values()).filter(inv => inv.productId === productId);
  }

  async updateInventory(productId: number, locationCode: string, quantity: number): Promise<Inventory | undefined> {
    // Find existing inventory record or create new one
    const existing = Array.from(this.inventory.values())
      .find(inv => inv.productId === productId && inv.locationCode === locationCode);
    
    if (existing) {
      existing.quantity = quantity;
      existing.lastUpdated = new Date();
      return existing;
    }
    
    const product = this.products.get(productId);
    if (!product) return undefined;
    
    const newInventory: Inventory = {
      id: this.currentInventoryId++,
      tenantId: product.tenantId,
      productId,
      locationCode,
      quantity,
      reservedQuantity: 0,
      reorderLevel: 0,
      lastUpdated: new Date(),
    };
    
    this.inventory.set(newInventory.id, newInventory);
    return newInventory;
  }

  // Dashboard metrics
  async getDashboardMetrics(tenantId: number): Promise<{
    totalInventory: number;
    pendingOrders: number;
    completedToday: number;
    warehouseCapacity: number;
  }> {
    const orders = await this.getOrders(tenantId);
    const products = await this.getProducts(tenantId);
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return {
      totalInventory: products.length * 1000 + Math.floor(Math.random() * 5000), // Simulated
      pendingOrders: orders.filter(o => o.status === 'pending' || o.status === 'processing').length,
      completedToday: orders.filter(o => 
        (o.status === 'shipped' || o.status === 'delivered') && 
        o.updatedAt >= today
      ).length,
      warehouseCapacity: 78, // Simulated percentage
    };
  }

  // Top moving products
  async getTopProducts(tenantId: number, limit: number): Promise<{
    product: Product;
    quantity: number;
    trend: string;
  }[]> {
    const products = await this.getProducts(tenantId);
    
    return products.slice(0, limit).map(product => ({
      product,
      quantity: Math.floor(Math.random() * 3000) + 500,
      trend: Math.random() > 0.3 ? `+${Math.floor(Math.random() * 20)}%` : `-${Math.floor(Math.random() * 10)}%`,
    }));
  }
}

export const storage = new MemStorage();
