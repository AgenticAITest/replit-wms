import { createContext, useContext, useState, ReactNode, useEffect } from "react";

export type UserRole = "tenantAdmin" | "manager" | "finance" | "worker";

interface RoleContextType {
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  availableRoles: UserRole[];
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export function RoleProvider({ children }: { children: ReactNode }) {
  const [currentRole, setCurrentRoleState] = useState<UserRole>("tenantAdmin");
  
  const availableRoles: UserRole[] = ["tenantAdmin", "manager", "finance", "worker"];

  useEffect(() => {
    const savedRole = localStorage.getItem("wms-user-role");
    if (savedRole && availableRoles.includes(savedRole as UserRole)) {
      setCurrentRoleState(savedRole as UserRole);
    }
  }, []);

  const setCurrentRole = (role: UserRole) => {
    setCurrentRoleState(role);
    localStorage.setItem("wms-user-role", role);
  };

  return (
    <RoleContext.Provider
      value={{
        currentRole,
        setCurrentRole,
        availableRoles,
      }}
    >
      {children}
    </RoleContext.Provider>
  );
}

export function useRole() {
  const context = useContext(RoleContext);
  if (context === undefined) {
    throw new Error("useRole must be used within a RoleProvider");
  }
  return context;
}