import { createContext, useContext, ReactNode } from "react";
import { useAuth } from "@/contexts/auth-context";
import { useRole } from "@/contexts/role-context";
import { hasPermission, canAccess, canManage, Permission, UserRole } from "@/lib/permissions";

interface PermissionContextType {
  hasPermission: (resource: string, requiredPermission?: Permission) => boolean;
  canAccess: (resource: string) => boolean;
  canManage: (resource: string) => boolean;
  currentRole: UserRole;
}

const PermissionContext = createContext<PermissionContextType | undefined>(undefined);

export function PermissionProvider({ children }: { children: ReactNode }) {
  const { currentRole } = useRole();

  const permissionHelpers = {
    hasPermission: (resource: string, requiredPermission: Permission = "VIEW") => 
      hasPermission(currentRole, resource, requiredPermission),
    canAccess: (resource: string) => canAccess(currentRole, resource),
    canManage: (resource: string) => canManage(currentRole, resource),
    currentRole
  };

  return (
    <PermissionContext.Provider value={permissionHelpers}>
      {children}
    </PermissionContext.Provider>
  );
}

export function usePermissions() {
  const context = useContext(PermissionContext);
  if (!context) {
    throw new Error("usePermissions must be used within a PermissionProvider");
  }
  return context;
}