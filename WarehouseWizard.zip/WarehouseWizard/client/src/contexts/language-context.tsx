import { createContext, useContext, useState, ReactNode, useEffect } from "react";

interface LanguageContextType {
  language: string;
  setLanguage: (lang: string) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Translation data
const translations: Record<string, Record<string, string>> = {
  en: {
    // Navigation
    "nav.dashboard": "Dashboard",
    "nav.inventory": "Inventory",
    "nav.warehouse": "Warehouse Layout",
    "nav.purchaseOrders": "Purchase Orders",
    "nav.salesOrders": "Sales Orders",
    "nav.workflow": "Workflow",
    "nav.users": "User & RBAC",
    "nav.reports": "Reports",
    "nav.settings": "Tenant Settings",
    "nav.myTasks": "My Tasks",
    "nav.scanItems": "Scan Items",
    "nav.updateStatus": "Update Status",
    "nav.financialReports": "Financial Reports",
    
    // Dashboard
    "dashboard.title": "Dashboard",
    "dashboard.subtitle": "Welcome back! Here's what's happening in your warehouse.",
    "dashboard.metrics.totalInventory": "Total Inventory",
    "dashboard.metrics.pendingOrders": "Pending Orders",
    "dashboard.metrics.completedToday": "Completed Today",
    "dashboard.metrics.warehouseCapacity": "Warehouse Capacity",
    "dashboard.orderTrends": "Order Trends",
    "dashboard.topMovingProducts": "Top Moving Products",
    "dashboard.recentOrders": "Recent Orders",
    
    // Common
    "common.search": "Search",
    "common.export": "Export",
    "common.viewAll": "View All",
    "common.actions": "Actions",
    "common.edit": "Edit",
    "common.view": "View",
    "common.delete": "Delete",
    "common.save": "Save",
    "common.cancel": "Cancel",
    "common.loading": "Loading...",
    "common.noData": "No data available",
    
    // Roles
    "role.tenantAdmin": "Tenant Admin",
    "role.manager": "Manager", 
    "role.finance": "Finance",
    "role.worker": "Worker",
    
    // Header
    "header.roleSelector": "Select Role",
    "header.languageSelector": "Language",
    "header.notifications": "Notifications",
    "header.profile": "Profile",
    "header.logout": "Logout"
  }
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<string>("en");

  useEffect(() => {
    const savedLanguage = localStorage.getItem("wms-language");
    if (savedLanguage && translations[savedLanguage]) {
      setLanguageState(savedLanguage);
    }
  }, []);

  const setLanguage = (lang: string) => {
    if (translations[lang]) {
      setLanguageState(lang);
      localStorage.setItem("wms-language", lang);
    }
  };

  const t = (key: string): string => {
    return translations[language]?.[key] || key;
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        t,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}