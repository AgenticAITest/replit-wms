import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart3, TrendingUp, PieChart } from "lucide-react";

export default function Reports() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Reports & Analytics</h1>
          <p className="text-gray-600">Analyze warehouse performance and generate insights</p>
        </div>
        <Badge variant="secondary">Coming in Phase 6+</Badge>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="h-5 w-5 mr-2" />
              Inventory Reports
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-6">
              <BarChart3 className="h-12 w-12 mx-auto text-gray-300 mb-3" />
              <p className="text-gray-600 text-sm">
                Stock levels, turnover rates, and inventory valuation reports
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="h-5 w-5 mr-2" />
              Performance Analytics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-6">
              <TrendingUp className="h-12 w-12 mx-auto text-gray-300 mb-3" />
              <p className="text-gray-600 text-sm">
                Order fulfillment metrics and efficiency tracking
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <PieChart className="h-5 w-5 mr-2" />
            Advanced Analytics Coming Soon
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <PieChart className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Comprehensive Reporting Suite</h3>
            <p className="text-gray-600 mb-4">
              Generate detailed reports and analytics for data-driven decisions:
            </p>
            <ul className="text-left text-gray-600 max-w-md mx-auto space-y-1">
              <li>• Real-time inventory dashboards</li>
              <li>• Order fulfillment analytics</li>
              <li>• Supplier performance metrics</li>
              <li>• Cost analysis and optimization</li>
              <li>• Custom report builder</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
