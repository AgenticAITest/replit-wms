import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function SystemSettings() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>System Settings</CardTitle>
      </CardHeader>
      <CardContent>
        <p>System settings features will be implemented in Phase 2.</p>
      </CardContent>
    </Card>
  );
}
