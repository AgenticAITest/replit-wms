import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Users, MapPin } from "lucide-react";
import { dataManager, type Customer } from "@/lib/data-manager";

export default function Customers() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [formData, setFormData] = useState({
    customerName: "",
    customerCode: "",
    contactPerson: "",
    email: "",
    phone: "",
    billingAddress: "",
    taxId: "",
    active: true,
    deliveryLocations: [{ label: "", fullAddress: "", latitude: 0, longitude: 0 }]
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setCustomers(dataManager.getCustomers());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingCustomer) {
      dataManager.updateCustomer(editingCustomer.id, {
        ...formData,
        tenantId: 1 // Mock tenant ID
      });
    } else {
      dataManager.saveCustomer({
        ...formData,
        tenantId: 1 // Mock tenant ID
      });
    }
    
    loadData();
    resetForm();
    setIsDialogOpen(false);
  };

  const handleEdit = (customer: Customer) => {
    setEditingCustomer(customer);
    setFormData({
      customerName: customer.customerName,
      customerCode: customer.customerCode,
      contactPerson: customer.contactPerson,
      email: customer.email,
      phone: customer.phone,
      billingAddress: customer.billingAddress,
      taxId: customer.taxId,
      active: customer.active,
      deliveryLocations: customer.deliveryLocations
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this customer?")) {
      dataManager.deleteCustomer(id);
      loadData();
    }
  };

  const resetForm = () => {
    setEditingCustomer(null);
    setFormData({
      customerName: "",
      customerCode: "",
      contactPerson: "",
      email: "",
      phone: "",
      billingAddress: "",
      taxId: "",
      active: true,
      deliveryLocations: [{ label: "", fullAddress: "", latitude: 0, longitude: 0 }]
    });
  };

  const addDeliveryLocation = () => {
    setFormData({
      ...formData,
      deliveryLocations: [...formData.deliveryLocations, { label: "", fullAddress: "", latitude: 0, longitude: 0 }]
    });
  };

  const updateDeliveryLocation = (index: number, field: string, value: string | number) => {
    const updated = [...formData.deliveryLocations];
    updated[index] = { ...updated[index], [field]: value };
    setFormData({ ...formData, deliveryLocations: updated });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Customer Management</h2>
          <p className="text-gray-600">Manage customers and their delivery locations</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="h-4 w-4 mr-2" />
              Add Customer
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingCustomer ? "Edit Customer" : "Add New Customer"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="customerName">Customer Name</Label>
                  <Input
                    id="customerName"
                    value={formData.customerName}
                    onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="customerCode">Customer Code</Label>
                  <Input
                    id="customerCode"
                    value={formData.customerCode}
                    onChange={(e) => setFormData({ ...formData, customerCode: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="contactPerson">Contact Person</Label>
                  <Input
                    id="contactPerson"
                    value={formData.contactPerson}
                    onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="taxId">Tax ID</Label>
                  <Input
                    id="taxId"
                    value={formData.taxId}
                    onChange={(e) => setFormData({ ...formData, taxId: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="billingAddress">Billing Address</Label>
                <Textarea
                  id="billingAddress"
                  value={formData.billingAddress}
                  onChange={(e) => setFormData({ ...formData, billingAddress: e.target.value })}
                  rows={3}
                  required
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="active"
                  checked={formData.active}
                  onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
                />
                <Label htmlFor="active">Active Customer</Label>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <Label>Delivery Locations</Label>
                  <Button type="button" variant="outline" size="sm" onClick={addDeliveryLocation}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Location
                  </Button>
                </div>
                
                {formData.deliveryLocations.map((location, index) => (
                  <Card key={index} className="p-4">
                    <div className="grid gap-4">
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-2">
                          <Label>Location Label</Label>
                          <Input
                            placeholder="e.g., Main Warehouse"
                            value={location.label}
                            onChange={(e) => updateDeliveryLocation(index, 'label', e.target.value)}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Coordinates (Lat, Lng)</Label>
                          <Input
                            placeholder="-6.2038, 106.8456"
                            onChange={(e) => {
                              const coords = e.target.value.split(',').map(c => parseFloat(c.trim()));
                              if (coords.length === 2) {
                                updateDeliveryLocation(index, 'latitude', coords[0]);
                                updateDeliveryLocation(index, 'longitude', coords[1]);
                              }
                            }}
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Full Address</Label>
                        <Textarea
                          placeholder="Complete delivery address"
                          value={location.fullAddress}
                          onChange={(e) => updateDeliveryLocation(index, 'fullAddress', e.target.value)}
                          rows={2}
                        />
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  {editingCustomer ? "Update Customer" : "Add Customer"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Users className="h-5 w-5 mr-2" />
            Customers ({customers.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Customer</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Delivery Locations</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {customers.map((customer) => (
                <TableRow key={customer.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{customer.customerName}</div>
                      <div className="text-sm text-gray-600">{customer.contactPerson}</div>
                    </div>
                  </TableCell>
                  <TableCell className="font-mono">{customer.customerCode}</TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>{customer.email}</div>
                      <div className="text-gray-600">{customer.phone}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center text-sm text-gray-600">
                      <MapPin className="h-4 w-4 mr-1" />
                      {customer.deliveryLocations.length} location(s)
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={customer.active ? "default" : "secondary"}>
                      {customer.active ? "Active" : "Inactive"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(customer)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(customer.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}