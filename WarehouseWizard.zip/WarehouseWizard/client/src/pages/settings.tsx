import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useToast } from "@/hooks/use-toast";
import { 
  Settings as SettingsIcon, 
  Database, 
  Warehouse, 
  Plug, 
  Package,
  Users,
  Building,
  Hash,
  Download,
  Upload,
  Trash2,
  Info,
  Plus,
  Pencil
} from "lucide-react";

// Import the master data pages we created in Phase 5
import InventoryPage from "./inventory";
import InventoryTypes from "./inventory-types";
import PackageTypes from "./package-types";
import Suppliers from "./suppliers";
import Customers from "./customers";
import { dataManager } from "@/lib/data-manager";
import InventoryItemsManager from "@/components/inventory-items-manager";

export default function Settings() {
  const [activeTab, setActiveTab] = useState("general");
  const [generalSettings, setGeneralSettings] = useState<any>({});
  const [smtpSettings, setSMTPSettings] = useState<any>({});
  const [apiSettings, setAPISettings] = useState<any>({});
  const [warehouseLayout, setWarehouseLayout] = useState<any>([]);
  const [poSettings, setPOSettings] = useState({
    prefix: "PO-",
    startNumber: 10001
  });
  const [soSettings, setSOSettings] = useState({
    prefix: "SO-",
    startNumber: 20001
  });
  
  // Warehouse management state
  const [warehouseDialogOpen, setWarehouseDialogOpen] = useState(false);
  const [warehouseEditMode, setWarehouseEditMode] = useState<'add' | 'edit'>('add');
  const [warehouseEditData, setWarehouseEditData] = useState<any>({});
  
  const { toast } = useToast();

  useEffect(() => {
    // Load all settings from storage
    setGeneralSettings(dataManager.getGeneralSettings());
    setSMTPSettings(dataManager.getSMTPSettings());
    setAPISettings(dataManager.getAPISettings());
    setWarehouseLayout(dataManager.getWarehouseHierarchy());
    
    // Load PO/SO settings from config
    const config = dataManager.getConfig();
    setPOSettings({
      prefix: config.purchaseOrders.prefix,
      startNumber: config.purchaseOrders.startCounter
    });
    setSOSettings({
      prefix: config.salesOrders.prefix,
      startNumber: config.salesOrders.startCounter
    });
  }, []);

  // Warehouse management handlers
  const handleWarehouseEdit = (type: string, item: any) => {
    setWarehouseEditMode('edit');
    setWarehouseEditData({ ...item, type });
    setWarehouseDialogOpen(true);
  };

  const handleWarehouseDelete = (type: string, zoneId: string, aisleId?: string, shelfId?: string, binId?: string) => {
    const itemName = type === 'zone' ? `Zone ${zoneId}` :
                    type === 'aisle' ? `Aisle ${zoneId}.${aisleId}` :
                    type === 'shelf' ? `Shelf ${zoneId}.${aisleId}.${shelfId}` :
                    `Bin ${zoneId}.${aisleId}.${shelfId}.${binId}`;
    
    if (confirm(`Are you sure you want to delete ${itemName}?`)) {
      try {
        let success = false;
        
        if (type === 'zone') {
          success = dataManager.deleteZone(zoneId);
        } else if (type === 'aisle' && aisleId !== undefined) {
          success = dataManager.deleteAisle(zoneId, aisleId);
        } else if (type === 'shelf' && aisleId !== undefined && shelfId !== undefined) {
          success = dataManager.deleteShelf(zoneId, aisleId, shelfId);
        } else if (type === 'bin' && aisleId !== undefined && shelfId !== undefined && binId !== undefined) {
          success = dataManager.deleteBin(zoneId, aisleId, shelfId, binId);
        }
        
        if (success) {
          setWarehouseLayout(dataManager.getWarehouseHierarchy());
          toast({
            title: "Success",
            description: `${itemName} deleted successfully`
          });
        } else {
          toast({
            title: "Cannot Delete",
            description: `Cannot delete ${itemName} because it contains child elements`,
            variant: "destructive"
          });
        }
      } catch (error: any) {
        toast({
          title: "Cannot Delete",
          description: error.message || `Failed to delete ${itemName}`,
          variant: "destructive"
        });
      }
    }
  };

  const handleWarehouseSave = () => {
    const { type, zoneId, number, displayName, capacity, aisleNumber, shelfNumber } = warehouseEditData;
    
    if (!displayName?.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a display name",
        variant: "destructive"
      });
      return;
    }

    try {
      let result = null;
      
      if (warehouseEditMode === 'add') {
        if (type === 'zone') {
          if (!zoneId?.trim()) {
            toast({
              title: "Validation Error",
              description: "Please enter a zone ID",
              variant: "destructive"
            });
            return;
          }
          result = dataManager.addZone(zoneId.toUpperCase(), displayName);
        } else if (type === 'aisle') {
          result = dataManager.addAisle(zoneId, number, displayName);
        } else if (type === 'shelf') {
          result = dataManager.addShelf(zoneId, aisleNumber, number, displayName);
        } else if (type === 'bin') {
          if (!capacity || capacity <= 0) {
            toast({
              title: "Validation Error",
              description: "Please enter a valid capacity",
              variant: "destructive"
            });
            return;
          }
          result = dataManager.addBin(zoneId, aisleNumber, shelfNumber, number, displayName, capacity);
        }
      } else {
        if (type === 'zone') {
          result = dataManager.updateZone(zoneId, displayName);
        } else if (type === 'aisle') {
          result = dataManager.updateAisle(zoneId, number, displayName);
        } else if (type === 'shelf') {
          result = dataManager.updateShelf(zoneId, aisleNumber, number, displayName);
        } else if (type === 'bin') {
          if (!capacity || capacity <= 0) {
            toast({
              title: "Validation Error",
              description: "Please enter a valid capacity",
              variant: "destructive"
            });
            return;
          }
          result = dataManager.updateBin(zoneId, aisleNumber, shelfNumber, number, displayName, capacity);
        }
      }
      
      if (result) {
        setWarehouseLayout(dataManager.getWarehouseHierarchy());
        setWarehouseDialogOpen(false);
        setWarehouseEditData({});
        toast({
          title: "Success",
          description: `${type.charAt(0).toUpperCase() + type.slice(1)} ${warehouseEditMode === 'add' ? 'added' : 'updated'} successfully`
        });
      } else {
        toast({
          title: "Error",
          description: `Failed to ${warehouseEditMode} ${type}`,
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : `Failed to ${warehouseEditMode} ${type}`,
        variant: "destructive"
      });
    }
  };

  const PlaceholderCard = ({ title, description, icon: Icon }: { title: string; description: string; icon: any }) => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Icon className="h-5 w-5 mr-2" />
          {title}
          <Badge variant="secondary" className="ml-auto">Coming in Phase 6+</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-gray-600">{description}</p>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-600">Configure your warehouse management system</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="masterdata">Master Data</TabsTrigger>
          <TabsTrigger value="warehouse">Warehouse Setup</TabsTrigger>
          <TabsTrigger value="integration">Integration</TabsTrigger>
          <TabsTrigger value="system">System</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <SettingsIcon className="h-5 w-5 mr-2" />
                General Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="companyName">Company Name</Label>
                  <Input 
                    id="companyName" 
                    value={generalSettings.companyName || ''} 
                    onChange={(e) => setGeneralSettings({...generalSettings, companyName: e.target.value})}
                    placeholder="Enter company name" 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="language">Preferred Language</Label>
                  <Select value={generalSettings.language} disabled>
                    <SelectTrigger className="opacity-50 cursor-not-allowed">
                      <SelectValue placeholder="Multilingual support coming soon" />
                    </SelectTrigger>
                  </Select>
                  <p className="text-xs text-gray-500">Multilingual support coming soon</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="companyAddress">Company Address</Label>
                <Textarea 
                  id="companyAddress" 
                  value={generalSettings.address || ''} 
                  onChange={(e) => setGeneralSettings({...generalSettings, address: e.target.value})}
                  placeholder="Enter complete company address" 
                  rows={3} 
                />
              </div>
              
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input 
                    id="phone" 
                    value={generalSettings.phone || ''} 
                    onChange={(e) => setGeneralSettings({...generalSettings, phone: e.target.value})}
                    placeholder="Enter phone number" 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input 
                    id="email" 
                    type="email"
                    value={generalSettings.email || ''} 
                    onChange={(e) => setGeneralSettings({...generalSettings, email: e.target.value})}
                    placeholder="Enter email address" 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="website">Website</Label>
                  <Input 
                    id="website" 
                    value={generalSettings.website || ''} 
                    onChange={(e) => setGeneralSettings({...generalSettings, website: e.target.value})}
                    placeholder="Enter website URL" 
                  />
                </div>
              </div>
              
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="currency">Preferred Currency</Label>
                  <Select value={generalSettings.currency} onValueChange={(value) => setGeneralSettings({...generalSettings, currency: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select currency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">USD - US Dollar</SelectItem>
                      <SelectItem value="IDR">IDR - Indonesian Rupiah</SelectItem>
                      <SelectItem value="EUR">EUR - Euro</SelectItem>
                      <SelectItem value="SGD">SGD - Singapore Dollar</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="timezone">Timezone</Label>
                  <Select value={generalSettings.timezone} onValueChange={(value) => setGeneralSettings({...generalSettings, timezone: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select timezone" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="UTC">UTC</SelectItem>
                      <SelectItem value="Asia/Jakarta">Asia/Jakarta</SelectItem>
                      <SelectItem value="Asia/Singapore">Asia/Singapore</SelectItem>
                      <SelectItem value="America/New_York">America/New_York</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="logo">Company Logo</Label>
                <div className="p-4 border-2 border-dashed border-gray-300 rounded-lg text-center">
                  <p className="text-sm text-gray-500">Upload not supported in preview mode</p>
                  <p className="text-xs text-gray-400 mt-1">This feature will be available when deployed</p>
                </div>
              </div>

              <div className="pt-4">
                <Button 
                  onClick={() => {
                    dataManager.updateGeneralSettings(generalSettings);
                    toast({
                      title: "Success",
                      description: "General settings saved successfully"
                    });
                  }}
                  className="w-full sm:w-auto"
                >
                  Save General Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="masterdata" className="space-y-4">
          <div className="grid gap-4">
            <Tabs defaultValue="inventory-items">
              <TabsList className="grid w-full grid-cols-6">
                <TabsTrigger value="inventory-items">Inventory Items</TabsTrigger>
                <TabsTrigger value="inventory-types">Inventory Types</TabsTrigger>
                <TabsTrigger value="package-types">Package Types</TabsTrigger>
                <TabsTrigger value="suppliers">Suppliers</TabsTrigger>
                <TabsTrigger value="customers">Customers</TabsTrigger>
                <TabsTrigger value="numbering">Numbering</TabsTrigger>
              </TabsList>

              <TabsContent value="inventory-items">
                <InventoryItemsManager />
              </TabsContent>

              <TabsContent value="inventory-types">
                <InventoryTypes />
              </TabsContent>

              <TabsContent value="package-types">
                <PackageTypes />
              </TabsContent>

              <TabsContent value="suppliers">
                <Suppliers />
              </TabsContent>

              <TabsContent value="customers">
                <Customers />
              </TabsContent>

              <TabsContent value="numbering">
                <div className="grid gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Hash className="h-5 w-5 mr-2" />
                        Purchase Order Numbering
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid gap-4 md:grid-cols-3">
                        <div className="space-y-2">
                          <Label htmlFor="poPrefix">Prefix</Label>
                          <Input 
                            id="poPrefix" 
                            placeholder="PO-" 
                            value={poSettings.prefix}
                            onChange={(e) => setPOSettings({...poSettings, prefix: e.target.value})}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="poStartNumber">Start Number</Label>
                          <Input 
                            id="poStartNumber" 
                            type="number" 
                            placeholder="10001" 
                            value={poSettings.startNumber}
                            onChange={(e) => setPOSettings({...poSettings, startNumber: parseInt(e.target.value) || 10001})}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Preview</Label>
                          <div className="px-3 py-2 bg-gray-50 rounded border text-gray-700">
                            {poSettings.prefix}{poSettings.startNumber}
                          </div>
                        </div>
                      </div>
                      <Button size="sm" onClick={() => {
                        const config = dataManager.getConfig();
                        dataManager.updateConfig({
                          ...config,
                          purchaseOrders: {
                            ...config.purchaseOrders,
                            prefix: poSettings.prefix,
                            startCounter: poSettings.startNumber
                          }
                        });
                        toast({
                          title: "Success",
                          description: "Purchase Order settings saved"
                        });
                      }}>Save PO Settings</Button>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Hash className="h-5 w-5 mr-2" />
                        Sales Order Numbering
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid gap-4 md:grid-cols-3">
                        <div className="space-y-2">
                          <Label htmlFor="soPrefix">Prefix</Label>
                          <Input 
                            id="soPrefix" 
                            placeholder="SO-" 
                            value={soSettings.prefix}
                            onChange={(e) => setSOSettings({...soSettings, prefix: e.target.value})}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="soStartNumber">Start Number</Label>
                          <Input 
                            id="soStartNumber" 
                            type="number" 
                            placeholder="20001" 
                            value={soSettings.startNumber}
                            onChange={(e) => setSOSettings({...soSettings, startNumber: parseInt(e.target.value) || 20001})}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Preview</Label>
                          <div className="px-3 py-2 bg-gray-50 rounded border text-gray-700">
                            {soSettings.prefix}{soSettings.startNumber}
                          </div>
                        </div>
                      </div>
                      <Button size="sm" onClick={() => {
                        const config = dataManager.getConfig();
                        dataManager.updateConfig({
                          ...config,
                          salesOrders: {
                            ...config.salesOrders,
                            prefix: soSettings.prefix,
                            startCounter: soSettings.startNumber
                          }
                        });
                        toast({
                          title: "Success",
                          description: "Sales Order settings saved"
                        });
                      }}>Save SO Settings</Button>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </TabsContent>

        <TabsContent value="warehouse" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Warehouse className="h-5 w-5 mr-2" />
                Warehouse Layout Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-gray-600">Configure zones, aisles, shelves, and bin locations with friendly names</p>
                    <p className="text-sm text-gray-500">Location IDs are auto-generated (e.g. Zone A → A.3.2.1 for Bin)</p>
                  </div>
                  <Dialog open={warehouseDialogOpen} onOpenChange={setWarehouseDialogOpen}>
                    <DialogTrigger asChild>
                      <Button size="sm" onClick={() => {
                        setWarehouseEditMode('add');
                        setWarehouseEditData({ type: 'zone', zoneId: '', displayName: '' });
                        setWarehouseDialogOpen(true);
                      }}>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Zone
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>
                          {warehouseEditMode === 'add' ? 'Add' : 'Edit'} {warehouseEditData.type?.charAt(0).toUpperCase() + warehouseEditData.type?.slice(1)}
                        </DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        {warehouseEditData.type === 'zone' && (
                          <>
                            <div className="space-y-2">
                              <Label htmlFor="zoneId">Zone ID</Label>
                              <Input
                                id="zoneId"
                                value={warehouseEditData.zoneId || ''}
                                onChange={(e) => setWarehouseEditData({...warehouseEditData, zoneId: e.target.value.toUpperCase()})}
                                placeholder="A"
                                maxLength={1}
                                disabled={warehouseEditMode === 'edit'}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="displayName">Display Name</Label>
                              <Input
                                id="displayName"
                                value={warehouseEditData.displayName || ''}
                                onChange={(e) => setWarehouseEditData({...warehouseEditData, displayName: e.target.value})}
                                placeholder="Baby Products"
                              />
                            </div>
                            <div className="text-sm text-gray-500">
                              Location ID: <code className="bg-gray-100 px-1 rounded">{warehouseEditData.zoneId || 'A'}</code>
                            </div>
                          </>
                        )}
                        
                        {warehouseEditData.type === 'aisle' && (
                          <>
                            <div className="space-y-2">
                              <Label htmlFor="number">Aisle Number</Label>
                              <Input
                                id="number"
                                type="number"
                                value={warehouseEditData.number || ''}
                                onChange={(e) => setWarehouseEditData({...warehouseEditData, number: parseInt(e.target.value) || 1})}
                                placeholder="1"
                                min={1}
                                disabled={warehouseEditMode === 'edit'}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="displayName">Display Name</Label>
                              <Input
                                id="displayName"
                                value={warehouseEditData.displayName || ''}
                                onChange={(e) => setWarehouseEditData({...warehouseEditData, displayName: e.target.value})}
                                placeholder="Main Corridor"
                              />
                            </div>
                            <div className="text-sm text-gray-500">
                              Location ID: <code className="bg-gray-100 px-1 rounded">{warehouseEditData.zoneId}.{warehouseEditData.number || '1'}</code>
                            </div>
                          </>
                        )}
                        
                        {warehouseEditData.type === 'shelf' && (
                          <>
                            <div className="space-y-2">
                              <Label htmlFor="number">Shelf Number</Label>
                              <Input
                                id="number"
                                type="number"
                                value={warehouseEditData.number || ''}
                                onChange={(e) => setWarehouseEditData({...warehouseEditData, number: parseInt(e.target.value) || 1})}
                                placeholder="1"
                                min={1}
                                disabled={warehouseEditMode === 'edit'}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="displayName">Display Name</Label>
                              <Input
                                id="displayName"
                                value={warehouseEditData.displayName || ''}
                                onChange={(e) => setWarehouseEditData({...warehouseEditData, displayName: e.target.value})}
                                placeholder="Upper Rack"
                              />
                            </div>
                            <div className="text-sm text-gray-500">
                              Location ID: <code className="bg-gray-100 px-1 rounded">{warehouseEditData.zoneId}.{warehouseEditData.aisleNumber}.{warehouseEditData.number || '1'}</code>
                            </div>
                          </>
                        )}
                        
                        {warehouseEditData.type === 'bin' && (
                          <>
                            <div className="space-y-2">
                              <Label htmlFor="number">Bin Number</Label>
                              <Input
                                id="number"
                                type="number"
                                value={warehouseEditData.number || ''}
                                onChange={(e) => setWarehouseEditData({...warehouseEditData, number: parseInt(e.target.value) || 1})}
                                placeholder="1"
                                min={1}
                                disabled={warehouseEditMode === 'edit'}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="displayName">Display Name</Label>
                              <Input
                                id="displayName"
                                value={warehouseEditData.displayName || ''}
                                onChange={(e) => setWarehouseEditData({...warehouseEditData, displayName: e.target.value})}
                                placeholder="Near Exit"
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="capacity">Capacity (m³)</Label>
                              <Input
                                id="capacity"
                                type="number"
                                step="0.1"
                                value={warehouseEditData.capacity || ''}
                                onChange={(e) => setWarehouseEditData({...warehouseEditData, capacity: parseFloat(e.target.value) || 1.0})}
                                placeholder="1.0"
                                min={0.1}
                              />
                            </div>
                            <div className="text-sm text-gray-500">
                              Location ID: <code className="bg-gray-100 px-1 rounded">{warehouseEditData.zoneId}.{warehouseEditData.aisleNumber}.{warehouseEditData.shelfNumber}.{warehouseEditData.number || '1'}</code>
                            </div>
                          </>
                        )}
                        
                        <div className="flex justify-end space-x-2">
                          <Button variant="outline" onClick={() => setWarehouseDialogOpen(false)}>
                            Cancel
                          </Button>
                          <Button onClick={handleWarehouseSave}>
                            {warehouseEditMode === 'add' ? 'Add' : 'Save'}
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
                
                <div className="border rounded-lg">
                  {warehouseLayout.length === 0 ? (
                    <div className="p-8 text-center text-gray-500">
                      <Warehouse className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>No warehouse zones configured</p>
                      <p className="text-sm">Add your first zone to get started</p>
                    </div>
                  ) : (
                    <Accordion type="single" collapsible className="w-full">
                      {warehouseLayout && Array.isArray(warehouseLayout) && warehouseLayout.length > 0 ? warehouseLayout.map((zone: any, zoneIndex: number) => (
                        <AccordionItem key={`zone-${zone.zoneId}`} value={`zone-${zone.zoneId}`}>
                          <AccordionTrigger className="px-4 py-3">
                            <div className="flex items-center justify-between w-full mr-4">
                              <div className="flex items-center space-x-3">
                                <Building className="h-5 w-5 text-blue-600" />
                                <div className="text-left">
                                  <div className="font-medium">Zone {zone.zoneId} – {zone.name}</div>
                                  <div className="text-sm text-gray-500">
                                    Location ID: <code className="bg-gray-100 px-1 rounded text-xs">{zone.zoneId}</code>
                                  </div>
                                </div>
                                <Badge variant="outline">{zone.aisles?.length || 0} aisles</Badge>
                              </div>
                              <div className="flex space-x-2" onClick={(e) => e.stopPropagation()}>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleWarehouseEdit('zone', zone)}
                                >
                                  <Pencil className="h-3 w-3" />
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleWarehouseDelete('zone', zone.zoneId)}
                                  disabled={zone.aisles?.length > 0}
                                >
                                  <Trash2 className="h-3 w-3" />
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => {
                                    setWarehouseEditMode('add');
                                    setWarehouseEditData({ 
                                      type: 'aisle', 
                                      zoneId: zone.zoneId, 
                                      number: (zone.aisles?.length || 0) + 1, 
                                      displayName: '' 
                                    });
                                    setWarehouseDialogOpen(true);
                                  }}
                                >
                                  <Plus className="h-3 w-3 mr-1" />
                                  Add Aisle
                                </Button>
                              </div>
                            </div>
                          </AccordionTrigger>
                          <AccordionContent className="px-4 pb-3">
                            {zone.aisles?.length === 0 ? (
                              <div className="text-center py-4 text-gray-500">
                                <p className="text-sm">No aisles in this zone</p>
                              </div>
                            ) : (
                              <Accordion type="single" collapsible>
                                {zone.aisles?.map((aisle: any, aisleIndex: number) => (
                                  <AccordionItem key={`aisle-${zone.zoneId}-${aisle.aisleId}-${aisleIndex}`} value={`aisle-${zone.zoneId}-${aisle.aisleId}-${aisleIndex}`}>
                                    <AccordionTrigger className="py-2">
                                      <div className="flex items-center justify-between w-full mr-4">
                                        <div className="flex items-center space-x-3">
                                          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                                          <div className="text-left">
                                            <div className="font-medium text-sm">Aisle {aisle.aisleId} – {aisle.name}</div>
                                            <div className="text-xs text-gray-500">
                                              Location ID: <code className="bg-gray-100 px-1 rounded">{zone.zoneId}.{aisle.aisleId}</code>
                                            </div>
                                          </div>
                                          <Badge variant="secondary" className="text-xs">{aisle.shelves?.length || 0} shelves</Badge>
                                        </div>
                                        <div className="flex space-x-1" onClick={(e) => e.stopPropagation()}>
                                          <Button 
                                            variant="ghost" 
                                            size="sm" 
                                            className="h-6 px-2"
                                            onClick={() => handleWarehouseEdit('aisle', { ...aisle, zoneId: zone.zoneId })}
                                          >
                                            <Pencil className="h-3 w-3" />
                                          </Button>
                                          <Button 
                                            variant="ghost" 
                                            size="sm" 
                                            className="h-6 px-2"
                                            onClick={() => handleWarehouseDelete('aisle', zone.zoneId, aisle.aisleId)}
                                            disabled={aisle.shelves?.length > 0}
                                          >
                                            <Trash2 className="h-3 w-3" />
                                          </Button>
                                          <Button 
                                            variant="ghost" 
                                            size="sm" 
                                            className="h-6 px-2"
                                            onClick={() => {
                                              setWarehouseEditMode('add');
                                              setWarehouseEditData({ 
                                                type: 'shelf', 
                                                zoneId: zone.zoneId, 
                                                aisleNumber: aisle.aisleId,
                                                number: (aisle.shelves?.length || 0) + 1, 
                                                displayName: '' 
                                              });
                                              setWarehouseDialogOpen(true);
                                            }}
                                          >
                                            <Plus className="h-3 w-3" />
                                          </Button>
                                        </div>
                                      </div>
                                    </AccordionTrigger>
                                    <AccordionContent className="pl-6">
                                      {aisle.shelves?.length === 0 ? (
                                        <div className="text-center py-4 text-gray-500">
                                          <p className="text-xs mb-2">No shelves in this aisle</p>
                                          <Button 
                                            variant="outline" 
                                            size="sm" 
                                            className="h-6 px-2"
                                            onClick={() => {
                                              setWarehouseEditMode('add');
                                              setWarehouseEditData({ 
                                                type: 'shelf', 
                                                zoneId: zone.zoneId, 
                                                aisleNumber: aisle.aisleId,
                                                number: 1, 
                                                displayName: '' 
                                              });
                                              setWarehouseDialogOpen(true);
                                            }}
                                          >
                                            <Plus className="h-3 w-3 mr-1" />
                                            Add First Shelf
                                          </Button>
                                        </div>
                                      ) : (
                                        <Accordion type="single" collapsible>
                                          {aisle.shelves?.map((shelf: any, shelfIndex: number) => (
                                            <AccordionItem key={`shelf-${zone.zoneId}-${aisle.aisleId}-${shelf.shelfId}`} value={`shelf-${zone.zoneId}-${aisle.aisleId}-${shelf.shelfId}`}>
                                              <AccordionTrigger className="py-1">
                                                <div className="flex items-center justify-between w-full mr-4">
                                                  <div className="flex items-center space-x-3">
                                                    <div className="w-2 h-2 bg-orange-400 rounded-full"></div>
                                                    <div className="text-left">
                                                      <div className="font-medium text-xs">Shelf {shelf.shelfId} – {shelf.name}</div>
                                                      <div className="text-xs text-gray-500">
                                                        Location ID: <code className="bg-gray-100 px-1 rounded">{zone.zoneId}.{aisle.aisleId}.{shelf.shelfId}</code>
                                                      </div>
                                                    </div>
                                                    <Badge variant="outline" className="text-xs">{shelf.bins?.length || 0} bins</Badge>
                                                  </div>
                                                  <div className="flex space-x-1" onClick={(e) => e.stopPropagation()}>
                                                    <Button 
                                                      variant="ghost" 
                                                      size="sm" 
                                                      className="h-5 px-1"
                                                      onClick={() => handleWarehouseEdit('shelf', { ...shelf, zoneId: zone.zoneId, aisleNumber: aisle.number })}
                                                    >
                                                      <Pencil className="h-2 w-2" />
                                                    </Button>
                                                    <Button 
                                                      variant="ghost" 
                                                      size="sm" 
                                                      className="h-5 px-1"
                                                      onClick={() => handleWarehouseDelete('shelf', zone.zoneId, aisle.aisleId, shelf.shelfId)}
                                                      disabled={shelf.bins?.length > 0}
                                                    >
                                                      <Trash2 className="h-2 w-2" />
                                                    </Button>
                                                    <Button 
                                                      variant="ghost" 
                                                      size="sm" 
                                                      className="h-5 px-1"
                                                      onClick={() => {
                                                        setWarehouseEditMode('add');
                                                        setWarehouseEditData({ 
                                                          type: 'bin', 
                                                          zoneId: zone.zoneId, 
                                                          aisleNumber: aisle.aisleId,
                                                          shelfNumber: shelf.shelfId,
                                                          number: (shelf.bins?.length || 0) + 1, 
                                                          displayName: '',
                                                          capacity: 1.0
                                                        });
                                                        setWarehouseDialogOpen(true);
                                                      }}
                                                    >
                                                      <Plus className="h-2 w-2" />
                                                    </Button>
                                                  </div>
                                                </div>
                                              </AccordionTrigger>
                                              <AccordionContent className="pl-6">
                                                {shelf.bins?.length === 0 ? (
                                                  <div className="text-center py-4 text-gray-500">
                                                    <p className="text-xs mb-2">No bins on this shelf</p>
                                                    <Button 
                                                      variant="outline" 
                                                      size="sm" 
                                                      className="h-6 px-2"
                                                      onClick={() => {
                                                        setWarehouseEditMode('add');
                                                        setWarehouseEditData({ 
                                                          type: 'bin', 
                                                          zoneId: zone.zoneId, 
                                                          aisleNumber: aisle.aisleId,
                                                          shelfNumber: shelf.shelfId,
                                                          number: 1, 
                                                          displayName: '',
                                                          capacity: 1.0
                                                        });
                                                        setWarehouseDialogOpen(true);
                                                      }}
                                                    >
                                                      <Plus className="h-3 w-3 mr-1" />
                                                      Add First Bin
                                                    </Button>
                                                  </div>
                                                ) : (
                                                  <div className="grid gap-2">
                                                    {shelf.bins?.map((bin: any, binIndex: number) => (
                                                      <div key={`bin-${zone.zoneId}-${aisle.aisleId}-${shelf.shelfId}-${bin.binId}`} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                                                        <div className="flex items-center space-x-2">
                                                          <div className="w-1 h-1 bg-purple-500 rounded-full"></div>
                                                          <div>
                                                            <div className="text-xs font-medium">Bin {bin.binId} – {bin.name}</div>
                                                            <div className="text-xs text-gray-500">
                                                              Location ID: <code className="bg-white px-1 rounded">{zone.zoneId}.{aisle.aisleId}.{shelf.shelfId}.{bin.binId}</code>
                                                              • Capacity: {bin.capacity} m³
                                                            </div>
                                                          </div>
                                                        </div>
                                                        <div className="flex space-x-1">
                                                          <Button 
                                                            variant="ghost" 
                                                            size="sm" 
                                                            className="h-5 px-1"
                                                            onClick={() => handleWarehouseEdit('bin', { 
                                                              ...bin, 
                                                              zoneId: zone.zoneId, 
                                                              aisleNumber: aisle.aisleId, 
                                                              shelfNumber: shelf.shelfId 
                                                            })}
                                                          >
                                                            <Pencil className="h-2 w-2" />
                                                          </Button>
                                                          <Button 
                                                            variant="ghost" 
                                                            size="sm" 
                                                            className="h-5 px-1"
                                                            onClick={() => handleWarehouseDelete('bin', zone.zoneId, aisle.aisleId, shelf.shelfId, bin.binId)}
                                                          >
                                                            <Trash2 className="h-2 w-2" />
                                                          </Button>
                                                        </div>
                                                      </div>
                                                    ))}
                                                  </div>
                                                )}
                                              </AccordionContent>
                                            </AccordionItem>
                                          ))}
                                        </Accordion>
                                      )}
                                    </AccordionContent>
                                  </AccordionItem>
                                ))}
                              </Accordion>
                            )}
                          </AccordionContent>
                        </AccordionItem>
                      )) : null}
                    </Accordion>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integration" className="space-y-4">
          <div className="grid gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Plug className="h-5 w-5 mr-2" />
                  SMTP Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="smtpHost">Host</Label>
                    <Input
                      id="smtpHost"
                      value={smtpSettings.host || ""}
                      onChange={(e) => setSMTPSettings({...smtpSettings, host: e.target.value})}
                      placeholder="smtp.gmail.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="smtpPort">Port</Label>
                    <Input
                      id="smtpPort"
                      type="number"
                      value={smtpSettings.port || ""}
                      onChange={(e) => setSMTPSettings({...smtpSettings, port: e.target.value})}
                      placeholder="587"
                    />
                  </div>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="smtpUsername">Username</Label>
                    <Input
                      id="smtpUsername"
                      value={smtpSettings.username || ""}
                      onChange={(e) => setSMTPSettings({...smtpSettings, username: e.target.value})}
                      placeholder="your-email@gmail.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="smtpPassword">Password</Label>
                    <Input
                      id="smtpPassword"
                      type="password"
                      value={smtpSettings.password || ""}
                      onChange={(e) => setSMTPSettings({...smtpSettings, password: e.target.value})}
                      placeholder="••••••••"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="senderEmail">Sender Email</Label>
                  <Input
                    id="senderEmail"
                    value={smtpSettings.senderEmail || ""}
                    onChange={(e) => setSMTPSettings({...smtpSettings, senderEmail: e.target.value})}
                    placeholder="notifications@yourcompany.com"
                  />
                </div>
                <div className="flex space-x-2">
                  <Button onClick={() => {
                    dataManager.updateSMTPSettings(smtpSettings);
                    toast({
                      title: "Success",
                      description: "SMTP settings saved"
                    });
                  }}>
                    Save SMTP Settings
                  </Button>
                  <Button variant="outline" onClick={() => {
                    toast({
                      title: "Test Connection",
                      description: "SMTP connection test successful (mocked)",
                    });
                  }}>
                    Test Connection
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Database className="h-5 w-5 mr-2" />
                  Inbound API Endpoints
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {apiSettings.inbound?.length > 0 ? (
                    <div className="space-y-3">
                      {apiSettings.inbound.map((api: any, index: number) => (
                        <div key={index} className="border rounded p-3">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <Badge variant="outline">{api.method}</Badge>
                                <span className="font-medium">{api.name}</span>
                              </div>
                              <p className="text-sm text-gray-600 mb-1">{api.description}</p>
                              <code className="text-xs bg-gray-100 px-2 py-1 rounded">{api.endpoint}</code>
                            </div>
                            <div className="flex space-x-1">
                              <Button variant="ghost" size="sm">Edit</Button>
                              <Button variant="ghost" size="sm">Delete</Button>
                            </div>
                          </div>
                          {api.samplePayload && (
                            <details className="mt-2">
                              <summary className="text-xs cursor-pointer">Sample Payload</summary>
                              <pre className="text-xs bg-gray-50 p-2 rounded mt-1 overflow-x-auto">
                                {JSON.stringify(api.samplePayload, null, 2)}
                              </pre>
                            </details>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <Database className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>No inbound API endpoints configured</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Plug className="h-5 w-5 mr-2" />
                    Outbound API Endpoints
                  </div>
                  <Button size="sm">
                    Add Endpoint
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {apiSettings.outbound?.length > 0 ? (
                    <div className="space-y-3">
                      {apiSettings.outbound.map((api: any, index: number) => (
                        <div key={index} className="border rounded p-3">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <span className="font-medium">{api.name}</span>
                                <Button variant="outline" size="sm" onClick={() => {
                                  toast({
                                    title: "Test Connection",
                                    description: `Connection to ${api.name} successful (mocked)`,
                                  });
                                }}>
                                  Test Connection
                                </Button>
                              </div>
                              <p className="text-sm text-gray-600 mb-1">{api.description}</p>
                              <code className="text-xs bg-gray-100 px-2 py-1 rounded">{api.endpoint}</code>
                            </div>
                            <div className="flex space-x-1">
                              <Button variant="ghost" size="sm">Edit</Button>
                              <Button variant="ghost" size="sm">Delete</Button>
                            </div>
                          </div>
                          {api.samplePayload && (
                            <details className="mt-2">
                              <summary className="text-xs cursor-pointer">Sample Payload</summary>
                              <pre className="text-xs bg-gray-50 p-2 rounded mt-1 overflow-x-auto">
                                {JSON.stringify(api.samplePayload, null, 2)}
                              </pre>
                            </details>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <Plug className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>No outbound API endpoints configured</p>
                      <p className="text-sm">Add your first endpoint to get started</p>
                    </div>
                  )}
                  
                  <div className="pt-4">
                    <Button onClick={() => {
                      dataManager.updateAPISettings(apiSettings);
                      toast({
                        title: "Success",
                        description: "API settings saved"
                      });
                    }}>
                      Save API Settings
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="system" className="space-y-4">
          <div className="grid gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Download className="h-5 w-5 mr-2" />
                  Backup Data
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">Download all current localStorage data as JSON backup</p>
                <Button onClick={() => {
                  dataManager.exportAllData();
                  toast({
                    title: "Success",
                    description: "Backup downloaded successfully"
                  });
                }}>
                  <Download className="h-4 w-4 mr-2" />
                  Download JSON Backup
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Upload className="h-5 w-5 mr-2" />
                  Restore Data
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">Upload and restore system data from JSON backup file</p>
                <div className="flex items-center gap-2">
                  <Input 
                    type="file" 
                    accept=".json" 
                    className="flex-1"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onload = (event) => {
                          try {
                            const jsonData = JSON.parse(event.target?.result as string);
                            const success = dataManager.importAllData(jsonData);
                            if (success) {
                              toast({
                                title: "Success",
                                description: "Data restored successfully. Please refresh the page."
                              });
                              // Reload settings after import
                              setGeneralSettings(dataManager.getGeneralSettings());
                              setSMTPSettings(dataManager.getSMTPSettings());
                              setAPISettings(dataManager.getAPISettings());
                              setWarehouseLayout(dataManager.getWarehouseLayout());
                            } else {
                              toast({
                                title: "Error",
                                description: "Failed to restore data. Please check the file format.",
                                variant: "destructive"
                              });
                            }
                          } catch (error) {
                            toast({
                              title: "Error",
                              description: "Invalid JSON file format",
                              variant: "destructive"
                            });
                          }
                        };
                        reader.readAsText(file);
                      }
                    }}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Info className="h-5 w-5 mr-2" />
                  Version Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">System Version:</span>
                    <span className="font-medium">v1.0.0-phase5d</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Last Updated:</span>
                    <span className="font-medium">June 30, 2025</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Build:</span>
                    <span className="font-medium">2025.06.30.5D</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Phase Status:</span>
                    <span className="font-medium text-green-600">Phase 5D Complete</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}