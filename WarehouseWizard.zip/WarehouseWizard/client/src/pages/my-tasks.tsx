import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function MyTasks() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>My Tasks</CardTitle>
      </CardHeader>
      <CardContent>
        <p>Worker task management features will be implemented in Phase 3.</p>
      </CardContent>
    </Card>
  );
}