import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Orders() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Order Management</CardTitle>
      </CardHeader>
      <CardContent>
        <p>Order management features will be implemented in Phase 2.</p>
      </CardContent>
    </Card>
  );
}
