import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function FinancialReports() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Financial Reports</CardTitle>
      </CardHeader>
      <CardContent>
        <p>Financial reporting features will be implemented in Phase 3.</p>
      </CardContent>
    </Card>
  );
}