import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function ScanItems() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Scan Items</CardTitle>
      </CardHeader>
      <CardContent>
        <p>Item scanning features will be implemented in Phase 3.</p>
      </CardContent>
    </Card>
  );
}