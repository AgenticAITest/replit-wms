import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function UpdateStatus() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Update Status</CardTitle>
      </CardHeader>
      <CardContent>
        <p>Status update features will be implemented in Phase 3.</p>
      </CardContent>
    </Card>
  );
}