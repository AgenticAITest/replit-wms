import { MetricsGrid } from "@/components/dashboard/metrics-grid";
import { OrderChart } from "@/components/dashboard/order-chart";
import { TopProducts } from "@/components/dashboard/top-products";
import { RecentOrders } from "@/components/dashboard/recent-orders";

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <MetricsGrid />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <OrderChart />
        <TopProducts />
      </div>
      
      <RecentOrders />
    </div>
  );
}
