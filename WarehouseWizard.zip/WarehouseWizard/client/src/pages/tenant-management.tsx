import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function TenantManagement() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Tenant Management</CardTitle>
      </CardHeader>
      <CardContent>
        <p>Tenant management features will be implemented in Phase 2.</p>
      </CardContent>
    </Card>
  );
}
