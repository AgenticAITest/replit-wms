import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Truck, MapPin, X } from "lucide-react";
import { dataManager, type Supplier, type PickupLocation } from "@/lib/data-manager";
import { useToast } from "@/hooks/use-toast";

export default function Suppliers() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [formData, setFormData] = useState({
    supplierName: "",
    supplierCode: "",
    contactPerson: "",
    email: "",
    phone: "",
    active: true,
    pickupLocations: [] as PickupLocation[]
  });
  const [newLocation, setNewLocation] = useState({
    addressName: "",
    fullAddress: "",
    latitude: 0,
    longitude: 0
  });
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setSuppliers(dataManager.getSuppliers());
  };

  const resetForm = () => {
    setFormData({
      supplierName: "",
      supplierCode: "",
      contactPerson: "",
      email: "",
      phone: "",
      active: true,
      pickupLocations: []
    });
    setNewLocation({
      addressName: "",
      fullAddress: "",
      latitude: 0,
      longitude: 0
    });
    setEditingSupplier(null);
  };

  const addPickupLocation = () => {
    if (!newLocation.addressName || !newLocation.fullAddress) {
      toast({
        title: "Validation Error",
        description: "Please fill in address name and full address",
        variant: "destructive"
      });
      return;
    }

    const location: PickupLocation = {
      id: Date.now(),
      ...newLocation
    };

    setFormData({
      ...formData,
      pickupLocations: [...formData.pickupLocations, location]
    });

    setNewLocation({
      addressName: "",
      fullAddress: "",
      latitude: 0,
      longitude: 0
    });
  };

  const removePickupLocation = (id: number) => {
    setFormData({
      ...formData,
      pickupLocations: formData.pickupLocations.filter(loc => loc.id !== id)
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.supplierName || !formData.supplierCode || !formData.contactPerson) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    if (formData.pickupLocations.length === 0) {
      toast({
        title: "Validation Error",
        description: "Please add at least one pickup location",
        variant: "destructive"
      });
      return;
    }

    try {
      if (editingSupplier) {
        dataManager.updateSupplier(editingSupplier.id, {
          ...formData,
          tenantId: 1
        });
        toast({
          title: "Success",
          description: "Supplier updated successfully"
        });
      } else {
        dataManager.saveSupplier({
          ...formData,
          tenantId: 1
        });
        toast({
          title: "Success",
          description: "Supplier created successfully"
        });
      }
      
      loadData();
      setIsDialogOpen(false);
      resetForm();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save supplier",
        variant: "destructive"
      });
    }
  };

  const handleEdit = (supplier: Supplier) => {
    setEditingSupplier(supplier);
    setFormData({
      supplierName: supplier.supplierName,
      supplierCode: supplier.supplierCode,
      contactPerson: supplier.contactPerson,
      email: supplier.email,
      phone: supplier.phone,
      active: supplier.active,
      pickupLocations: supplier.pickupLocations
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this supplier?")) {
      try {
        dataManager.deleteSupplier(id);
        loadData();
        toast({
          title: "Success",
          description: "Supplier deleted successfully"
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to delete supplier",
          variant: "destructive"
        });
      }
    }
  };

  const openNewDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Supplier Management</h1>
          <p className="text-gray-600">Manage suppliers and their pickup locations</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openNewDialog}>
              <Plus className="h-4 w-4 mr-2" />
              Add Supplier
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingSupplier ? "Edit Supplier" : "Add New Supplier"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="supplierName">Supplier Name *</Label>
                  <Input
                    id="supplierName"
                    value={formData.supplierName}
                    onChange={(e) => setFormData({ ...formData, supplierName: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="supplierCode">Supplier Code *</Label>
                  <Input
                    id="supplierCode"
                    value={formData.supplierCode}
                    onChange={(e) => setFormData({ ...formData, supplierCode: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="contactPerson">Contact Person *</Label>
                  <Input
                    id="contactPerson"
                    value={formData.contactPerson}
                    onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="active"
                  checked={formData.active}
                  onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
                />
                <Label htmlFor="active">Active</Label>
              </div>

              <div className="space-y-4">
                <Label className="text-base font-medium">Pickup Locations</Label>
                
                {/* Add New Location */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Add Pickup Location</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="addressName">Address Name</Label>
                        <Input
                          id="addressName"
                          value={newLocation.addressName}
                          onChange={(e) => setNewLocation({ ...newLocation, addressName: e.target.value })}
                          placeholder="e.g., Main Warehouse"
                        />
                      </div>
                      <div>
                        <Label htmlFor="fullAddress">Full Address</Label>
                        <Input
                          id="fullAddress"
                          value={newLocation.fullAddress}
                          onChange={(e) => setNewLocation({ ...newLocation, fullAddress: e.target.value })}
                          placeholder="Complete address"
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="coordinates">Coordinates (Lat, Lng)</Label>
                      <Input
                        id="coordinates"
                        placeholder="-6.2038, 106.8456"
                        onChange={(e) => {
                          const coords = e.target.value.split(',').map(c => parseFloat(c.trim()));
                          if (coords.length === 2 && !isNaN(coords[0]) && !isNaN(coords[1])) {
                            setNewLocation({ 
                              ...newLocation, 
                              latitude: coords[0], 
                              longitude: coords[1] 
                            });
                          }
                        }}
                      />
                    </div>
                    <Button type="button" onClick={addPickupLocation} variant="outline">
                      <MapPin className="h-4 w-4 mr-2" />
                      Add Location
                    </Button>
                  </CardContent>
                </Card>

                {/* Existing Locations */}
                {formData.pickupLocations.length > 0 && (
                  <div className="space-y-2">
                    <Label className="text-sm">Current Pickup Locations</Label>
                    {formData.pickupLocations.map((location) => (
                      <Card key={location.id}>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <div className="font-medium">{location.addressName}</div>
                              <div className="text-sm text-gray-600">{location.fullAddress}</div>
                              <div className="text-xs text-gray-500">
                                Lat: {location.latitude}, Lng: {location.longitude}
                              </div>
                            </div>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => removePickupLocation(location.id)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  {editingSupplier ? "Update" : "Create"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Truck className="h-5 w-5 mr-2" />
            Suppliers
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Supplier</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Locations</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {suppliers.map((supplier) => (
                <TableRow key={supplier.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{supplier.supplierName}</div>
                      <div className="text-sm text-gray-600">{supplier.contactPerson}</div>
                    </div>
                  </TableCell>
                  <TableCell className="font-mono">{supplier.supplierCode}</TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>{supplier.email}</div>
                      <div className="text-gray-600">{supplier.phone}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {supplier.pickupLocations.length} location{supplier.pickupLocations.length !== 1 ? 's' : ''}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={supplier.active ? "default" : "secondary"}>
                      {supplier.active ? "Active" : "Inactive"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(supplier)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(supplier.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}