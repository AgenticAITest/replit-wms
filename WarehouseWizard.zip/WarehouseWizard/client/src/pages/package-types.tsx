import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Package2 } from "lucide-react";
import { dataManager, type PackageType } from "@/lib/data-manager";
import { useToast } from "@/hooks/use-toast";

export default function PackageTypes() {
  const [packageTypes, setPackageTypes] = useState<PackageType[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingType, setEditingType] = useState<PackageType | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    active: true
  });
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setPackageTypes(dataManager.getPackageTypes());
  };

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      active: true
    });
    setEditingType(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a package type name",
        variant: "destructive"
      });
      return;
    }

    // Business logic: Check if trying to deactivate a type that's in use
    if (editingType && editingType.active && !formData.active) {
      const inventoryItems = dataManager.getInventory();
      const isTypeInUse = inventoryItems.some(item => item.packageType === editingType.name);
      
      if (isTypeInUse) {
        toast({
          title: "Cannot Deactivate",
          description: "This package type is currently being used by inventory items and cannot be deactivated.",
          variant: "destructive"
        });
        return;
      }
    }

    try {
      if (editingType) {
        dataManager.updatePackageType(editingType.id, formData);
        toast({
          title: "Success",
          description: "Package type updated successfully"
        });
      } else {
        dataManager.savePackageType(formData);
        toast({
          title: "Success",
          description: "Package type created successfully"
        });
      }
      
      loadData();
      setIsDialogOpen(false);
      resetForm();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save package type",
        variant: "destructive"
      });
    }
  };

  const handleEdit = (type: PackageType) => {
    setEditingType(type);
    setFormData({
      name: type.name,
      description: type.description,
      active: type.active
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this package type?")) {
      try {
        dataManager.deletePackageType(id);
        loadData();
        toast({
          title: "Success",
          description: "Package type deleted successfully"
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to delete package type",
          variant: "destructive"
        });
      }
    }
  };

  const openNewDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Package Types</h1>
          <p className="text-gray-600">Manage packaging types used for inventory items</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openNewDialog}>
              <Plus className="h-4 w-4 mr-2" />
              Add Type
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingType ? "Edit Package Type" : "Add New Package Type"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Package Type Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="active"
                  checked={formData.active}
                  onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
                />
                <Label htmlFor="active">Active</Label>
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  {editingType ? "Update" : "Create"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Package2 className="h-5 w-5 mr-2" />
            Package Types
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {packageTypes.map((type) => (
                <TableRow key={type.id}>
                  <TableCell className="font-medium">{type.name}</TableCell>
                  <TableCell>{type.description}</TableCell>
                  <TableCell>
                    <Badge variant={type.active ? "default" : "secondary"}>
                      {type.active ? "Active" : "Inactive"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(type)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(type.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}