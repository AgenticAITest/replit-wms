import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart } from "lucide-react";

export default function PurchaseOrders() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Purchase Orders</h1>
          <p className="text-gray-600">Manage supplier purchase orders and receiving</p>
        </div>
        <Badge variant="secondary">Coming in Phase 6+</Badge>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <ShoppingCart className="h-5 w-5 mr-2" />
            Purchase Order Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <ShoppingCart className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Purchase Orders Coming Soon</h3>
            <p className="text-gray-600 mb-4">
              Create, manage, and track purchase orders from suppliers. Features will include:
            </p>
            <ul className="text-left text-gray-600 max-w-md mx-auto space-y-1">
              <li>• Create POs from inventory needs</li>
              <li>• Track delivery status</li>
              <li>• Receive and verify shipments</li>
              <li>• Update inventory upon receipt</li>
              <li>• Supplier performance tracking</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}