import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Warehouse as WarehouseIcon, MapPin } from "lucide-react";

export default function Warehouse() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Warehouse Layout</h1>
          <p className="text-gray-600">View warehouse capacity and structural layout</p>
        </div>
        <Badge variant="outline">Read-Only View</Badge>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <WarehouseIcon className="h-5 w-5 mr-2" />
              Capacity Overview
              <Badge variant="secondary" className="ml-auto">Coming in Phase 6+</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <WarehouseIcon className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Layout Visualization Coming Soon</h3>
              <p className="text-gray-600 mb-4">
                View warehouse capacity by zone and bin utilization. Features will include:
              </p>
              <ul className="text-left text-gray-600 max-w-md mx-auto space-y-1">
                <li>• Real-time capacity by zone/aisle/bin</li>
                <li>• Visual layout with occupancy heatmap</li>
                <li>• Available space calculations</li>
                <li>• Item location tracking</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <MapPin className="h-5 w-5 mr-2" />
              Structure Layout
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 rounded-lg p-6">
              <p className="text-gray-600 text-center">
                <strong>Note:</strong> To configure zones, aisles, shelves, and bins, go to 
                <span className="font-medium text-blue-600"> Settings → Warehouse Setup</span>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
