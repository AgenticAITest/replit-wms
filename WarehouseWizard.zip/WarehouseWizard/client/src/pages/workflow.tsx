import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GitBranch } from "lucide-react";

export default function Workflow() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Workflow Management</h1>
          <p className="text-gray-600">Automate and manage warehouse processes</p>
        </div>
        <Badge variant="secondary">Coming in Phase 6+</Badge>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <GitBranch className="h-5 w-5 mr-2" />
            Process Automation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <GitBranch className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Workflow Automation Coming Soon</h3>
            <p className="text-gray-600 mb-4">
              Design and manage automated warehouse workflows for efficiency:
            </p>
            <ul className="text-left text-gray-600 max-w-md mx-auto space-y-1">
              <li>• Automated reorder triggers</li>
              <li>• Pick and pack workflows</li>
              <li>• Quality control processes</li>
              <li>• Alert and notification rules</li>
              <li>• Custom workflow designer</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
