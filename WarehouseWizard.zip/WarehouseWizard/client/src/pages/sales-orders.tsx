import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Truck } from "lucide-react";

export default function SalesOrders() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Sales Orders</h1>
          <p className="text-gray-600">Manage customer orders and fulfillment</p>
        </div>
        <Badge variant="secondary">Coming in Phase 6+</Badge>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Truck className="h-5 w-5 mr-2" />
            Sales Order Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Truck className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Sales Orders Coming Soon</h3>
            <p className="text-gray-600 mb-4">
              Process and fulfill customer orders with full order lifecycle management:
            </p>
            <ul className="text-left text-gray-600 max-w-md mx-auto space-y-1">
              <li>• Create orders from customer requests</li>
              <li>• Inventory allocation and picking</li>
              <li>• Packing and shipping management</li>
              <li>• Order tracking and status updates</li>
              <li>• Customer delivery confirmations</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}