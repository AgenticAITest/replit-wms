import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";

export function useUser(id: number) {
  return useQuery<User>({
    queryKey: ["/api/users", id],
    enabled: !!id,
  });
}

export function useUsersByTenant(tenantId: number) {
  return useQuery<User[]>({
    queryKey: ["/api/users/tenant", tenantId],
    enabled: !!tenantId,
  });
}
