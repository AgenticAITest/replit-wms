import { useEffect } from "react";
import { useLocation } from "wouter";
import { usePermissions } from "@/contexts/permission-context";

// Map paths to resource names for permission checking
const pathToResource: Record<string, string> = {
  "/": "dashboard",
  "/inventory": "inventory",
  "/orders": "orders",
  "/warehouse": "warehouse",
  "/workflow": "workflow",
  "/users": "users",
  "/reports": "reports",
  "/settings": "settings",
  "/tenant-management": "tenantManagement",
  "/system-settings": "systemSettings",
  "/purchase-orders": "purchaseOrders",
  "/sales-orders": "salesOrders",
  "/my-tasks": "myTasks",
  "/scan-items": "scanItems",
  "/update-status": "updateStatus",
  "/financial-reports": "financialReports"
};

export function useRoleRedirect() {
  const [location, setLocation] = useLocation();
  const { canAccess, currentRole } = usePermissions();

  useEffect(() => {
    const currentResource = pathToResource[location];
    
    if (currentResource && !canAccess(currentResource)) {
      // Find the first accessible page for this role
      const accessiblePaths = Object.entries(pathToResource).filter(([path, resource]) => 
        canAccess(resource)
      );
      
      if (accessiblePaths.length > 0) {
        // Redirect to the first accessible page
        setLocation(accessiblePaths[0][0]);
      }
    }
  }, [currentRole, location, canAccess, setLocation]);
}