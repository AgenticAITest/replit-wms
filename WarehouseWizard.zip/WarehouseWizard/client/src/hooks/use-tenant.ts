import { useQuery } from "@tanstack/react-query";
import { Tenant } from "@shared/schema";

export function useTenants() {
  return useQuery<Tenant[]>({
    queryKey: ["/api/tenants"],
  });
}

export function useTenant(id: number) {
  return useQuery<Tenant>({
    queryKey: ["/api/tenants", id],
    enabled: !!id,
  });
}
