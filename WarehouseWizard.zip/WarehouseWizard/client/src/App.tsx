import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { TenantProvider } from "@/contexts/tenant-context";
import { AuthProvider } from "@/contexts/auth-context";
import { RoleProvider } from "@/contexts/role-context";
import { PermissionProvider } from "@/contexts/permission-context";
import { LanguageProvider } from "@/contexts/language-context";

// Pages
import Dashboard from "@/pages/dashboard";
import Inventory from "@/pages/inventory";
import Orders from "@/pages/orders";
import Warehouse from "@/pages/warehouse";
import Workflow from "@/pages/workflow";
import Users from "@/pages/users";
import Reports from "@/pages/reports";
import Settings from "@/pages/settings";
import TenantManagement from "@/pages/tenant-management";
import SystemSettings from "@/pages/system-settings";
import PurchaseOrders from "@/pages/purchase-orders";
import SalesOrders from "@/pages/sales-orders";
import MyTasks from "@/pages/my-tasks";
import ScanItems from "@/pages/scan-items";
import UpdateStatus from "@/pages/update-status";
import FinancialReports from "@/pages/financial-reports";
import NotFound from "@/pages/not-found";
import Login from "@/pages/login";
import { ProtectedRoute } from "@/components/protected-route";
import { AuthWrapper } from "@/components/auth-wrapper";

function Router() {
  return (
    <AuthWrapper>
      <Switch>
        <Route path="/login">
          <Login />
        </Route>
        <Route path="/">
          <ProtectedRoute resource="dashboard">
            <Dashboard />
          </ProtectedRoute>
        </Route>
        <Route path="/inventory">
          <ProtectedRoute resource="inventory">
            <Inventory />
          </ProtectedRoute>
        </Route>
        <Route path="/orders">
          <ProtectedRoute resource="orders">
            <Orders />
          </ProtectedRoute>
        </Route>
        <Route path="/warehouse">
          <ProtectedRoute resource="warehouse">
            <Warehouse />
          </ProtectedRoute>
        </Route>
        <Route path="/workflow">
          <ProtectedRoute resource="workflow">
            <Workflow />
          </ProtectedRoute>
        </Route>
        <Route path="/users">
          <ProtectedRoute resource="users">
            <Users />
          </ProtectedRoute>
        </Route>
        <Route path="/reports">
          <ProtectedRoute resource="reports">
            <Reports />
          </ProtectedRoute>
        </Route>
        <Route path="/settings">
          <ProtectedRoute resource="settings">
            <Settings />
          </ProtectedRoute>
        </Route>
        <Route path="/tenant-management">
          <ProtectedRoute resource="tenantManagement">
            <TenantManagement />
          </ProtectedRoute>
        </Route>
        <Route path="/system-settings">
          <ProtectedRoute resource="systemSettings">
            <SystemSettings />
          </ProtectedRoute>
        </Route>
        <Route path="/purchase-orders">
          <ProtectedRoute resource="purchaseOrders">
            <PurchaseOrders />
          </ProtectedRoute>
        </Route>
        <Route path="/sales-orders">
          <ProtectedRoute resource="salesOrders">
            <SalesOrders />
          </ProtectedRoute>
        </Route>
        <Route path="/my-tasks">
          <ProtectedRoute resource="myTasks">
            <MyTasks />
          </ProtectedRoute>
        </Route>
        <Route path="/scan-items">
          <ProtectedRoute resource="scanItems">
            <ScanItems />
          </ProtectedRoute>
        </Route>
        <Route path="/update-status">
          <ProtectedRoute resource="updateStatus">
            <UpdateStatus />
          </ProtectedRoute>
        </Route>
        <Route path="/financial-reports">
          <ProtectedRoute resource="financialReports">
            <FinancialReports />
          </ProtectedRoute>
        </Route>
        <Route component={NotFound} />
      </Switch>
    </AuthWrapper>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <LanguageProvider>
          <AuthProvider>
            <RoleProvider>
              <PermissionProvider>
                <TenantProvider>
                  <Toaster />
                  <Router />
                </TenantProvider>
              </PermissionProvider>
            </RoleProvider>
          </AuthProvider>
        </LanguageProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
