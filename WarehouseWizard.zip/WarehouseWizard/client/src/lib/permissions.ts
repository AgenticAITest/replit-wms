export type Permission = "MANAGE" | "VIEW" | "NO_ACCESS";
export type UserRole = "tenantAdmin" | "manager" | "finance" | "worker";

export interface PermissionMatrix {
  [role: string]: {
    [resource: string]: Permission;
  };
}

// Define the permission matrix based on the RBAC requirements
export const PERMISSIONS: PermissionMatrix = {
  tenantAdmin: {
    dashboard: "MANAGE",
    inventory: "MANAGE",
    warehouse: "MANAGE",
    purchaseOrders: "MANAGE",
    salesOrders: "MANAGE",
    workflow: "MANAGE",
    users: "MANAGE",
    reports: "MANAGE",
    settings: "MANAGE",
    tenantManagement: "MANAGE",
    systemSettings: "MANAGE",
    myTasks: "NO_ACCESS",
    scanItems: "NO_ACCESS",
    updateStatus: "NO_ACCESS",
    financialReports: "MANAGE"
  },
  manager: {
    dashboard: "MANAGE",
    inventory: "MANAGE",
    warehouse: "MANAGE",
    purchaseOrders: "MANAGE",
    salesOrders: "MANAGE",
    workflow: "MANAGE",
    users: "NO_ACCESS",
    reports: "MANAGE",
    settings: "NO_ACCESS",
    tenantManagement: "NO_ACCESS",
    systemSettings: "NO_ACCESS",
    myTasks: "NO_ACCESS",
    scanItems: "NO_ACCESS",
    updateStatus: "NO_ACCESS",
    financialReports: "VIEW"
  },
  finance: {
    dashboard: "VIEW",
    inventory: "NO_ACCESS",
    warehouse: "NO_ACCESS",
    purchaseOrders: "MANAGE",
    salesOrders: "MANAGE",
    workflow: "NO_ACCESS",
    users: "NO_ACCESS",
    reports: "NO_ACCESS",
    settings: "NO_ACCESS",
    tenantManagement: "NO_ACCESS",
    systemSettings: "NO_ACCESS",
    myTasks: "NO_ACCESS",
    scanItems: "NO_ACCESS",
    updateStatus: "NO_ACCESS",
    financialReports: "MANAGE"
  },
  worker: {
    dashboard: "VIEW",
    inventory: "NO_ACCESS",
    warehouse: "NO_ACCESS",
    purchaseOrders: "NO_ACCESS",
    salesOrders: "NO_ACCESS",
    workflow: "NO_ACCESS",
    users: "NO_ACCESS",
    reports: "NO_ACCESS",
    settings: "NO_ACCESS",
    tenantManagement: "NO_ACCESS",
    systemSettings: "NO_ACCESS",
    myTasks: "MANAGE",
    scanItems: "MANAGE",
    updateStatus: "MANAGE",
    financialReports: "NO_ACCESS"
  }
};

export function hasPermission(
  role: UserRole,
  resource: string,
  requiredPermission: Permission = "VIEW"
): boolean {
  const userPermissions = PERMISSIONS[role];
  if (!userPermissions) return false;
  
  const permission = userPermissions[resource];
  if (!permission || permission === "NO_ACCESS") return false;
  
  // If they need MANAGE but only have VIEW, deny access
  if (requiredPermission === "MANAGE" && permission === "VIEW") return false;
  
  return true;
}

export function canAccess(role: UserRole, resource: string): boolean {
  return hasPermission(role, resource, "VIEW");
}

export function canManage(role: UserRole, resource: string): boolean {
  return hasPermission(role, resource, "MANAGE");
}