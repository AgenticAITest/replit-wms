export interface MockUser {
  email: string;
  password: string;
  role: "tenantAdmin" | "manager" | "finance" | "worker";
  tenantId: string;
  firstName: string;
  lastName: string;
  name: string;
  id: number;
}

export const MOCK_USERS: MockUser[] = [
  // ABC Logistics Users
  {
    id: 1,
    email: "admin@abc.com",
    password: "admin123",
    role: "tenantAdmin",
    tenantId: "tenant-abc",
    firstName: "John",
    lastName: "Admin",
    name: "John Admin"
  },
  {
    id: 2,
    email: "manager@abc.com",
    password: "manager123",
    role: "manager",
    tenantId: "tenant-abc",
    firstName: "Sarah",
    lastName: "Manager",
    name: "Sarah Manager"
  },
  {
    id: 3,
    email: "finance@abc.com",
    password: "finance123",
    role: "finance",
    tenantId: "tenant-abc",
    firstName: "Mike",
    lastName: "Finance",
    name: "Mike Finance"
  },
  {
    id: 4,
    email: "worker@abc.com",
    password: "worker123",
    role: "worker",
    tenantId: "tenant-abc",
    firstName: "Lisa",
    lastName: "Worker",
    name: "Lisa Worker"
  },
  // XYZ Warehouse Users
  {
    id: 5,
    email: "admin@xyz.com",
    password: "admin123",
    role: "tenantAdmin",
    tenantId: "tenant-xyz",
    firstName: "David",
    lastName: "Admin",
    name: "David Admin"
  },
  {
    id: 6,
    email: "manager@xyz.com",
    password: "manager123",
    role: "manager",
    tenantId: "tenant-xyz",
    firstName: "Emma",
    lastName: "Manager",
    name: "Emma Manager"
  },
  {
    id: 7,
    email: "finance@xyz.com",
    password: "finance123",
    role: "finance",
    tenantId: "tenant-xyz",
    firstName: "James",
    lastName: "Finance",
    name: "James Finance"
  },
  {
    id: 8,
    email: "worker@xyz.com",
    password: "worker123",
    role: "worker",
    tenantId: "tenant-xyz",
    firstName: "Anna",
    lastName: "Worker",
    name: "Anna Worker"
  }
];

export const MOCK_TENANTS = {
  "tenant-abc": {
    id: "tenant-abc",
    name: "ABC Logistics",
    domain: "abc.com"
  },
  "tenant-xyz": {
    id: "tenant-xyz",
    name: "XYZ Warehouse",
    domain: "xyz.com"
  }
};

export function validateLogin(email: string, password: string): MockUser | null {
  const user = MOCK_USERS.find(u => u.email === email && u.password === password);
  return user || null;
}

export function getTenantName(tenantId: string): string {
  return MOCK_TENANTS[tenantId as keyof typeof MOCK_TENANTS]?.name || "Unknown Tenant";
}