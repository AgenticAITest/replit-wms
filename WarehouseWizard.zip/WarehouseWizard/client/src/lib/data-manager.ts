// Data persistence layer for mock data using localStorage
import inventoryData from '@/data/inventory.json';
import inventoryTypesData from '@/data/inventoryTypes.json';
import packageTypesData from '@/data/packageTypes.json';
import suppliersData from '@/data/suppliers.json';
import customersData from '@/data/customers.json';
import configData from '@/data/config.json';

export interface InventoryItem {
  id: number;
  sku: string;
  itemName: string;
  inventoryType: string;
  packageType: string;
  size: string;
  weight: string;
  minimumStockLevel: number;
  hasExpiry: boolean;
  expiryDate: string | null;
  tenantId: number;
  createdAt: string;
  currentStock?: number; // For stock tracking - will be implemented in Phase 6
  active: boolean; // Active/Inactive status for inventory items
}

export interface InventoryType {
  id: number;
  name: string;
  description: string;
  active: boolean;
}

export interface PackageType {
  id: number;
  name: string;
  description: string;
  active: boolean;
}

export interface PickupLocation {
  id: number;
  addressName: string;
  fullAddress: string;
  latitude: number;
  longitude: number;
}

export interface Supplier {
  id: number;
  supplierName: string;
  supplierCode: string;
  contactPerson: string;
  email: string;
  phone: string;
  active: boolean;
  pickupLocations: PickupLocation[];
  tenantId: number;
  createdAt: string;
}

export interface DeliveryLocation {
  id: number;
  label: string;
  fullAddress: string;
  latitude: number;
  longitude: number;
}

export interface Customer {
  id: number;
  customerName: string;
  customerCode: string;
  contactPerson: string;
  email: string;
  phone: string;
  billingAddress: string;
  taxId: string;
  active: boolean;
  deliveryLocations: DeliveryLocation[];
  tenantId: number;
  createdAt: string;
}

export interface OrderConfig {
  prefix: string;
  startCounter: number;
  dateFormat: string;
}

export interface Config {
  purchaseOrders: OrderConfig;
  salesOrders: OrderConfig;
  tenantId: number;
}

class DataManager {
  private getStorageKey(dataType: string): string {
    return `wms_${dataType}`;
  }

  private loadFromStorage<T>(dataType: string, defaultData: T[]): T[] {
    try {
      const stored = localStorage.getItem(this.getStorageKey(dataType));
      return stored ? JSON.parse(stored) : defaultData;
    } catch {
      return defaultData;
    }
  }

  private saveToStorage<T>(dataType: string, data: T[]): void {
    try {
      localStorage.setItem(this.getStorageKey(dataType), JSON.stringify(data));
    } catch (error) {
      console.error(`Failed to save ${dataType} to localStorage:`, error);
    }
  }

  private getNextId<T extends { id: number }>(items: T[]): number {
    return Math.max(0, ...items.map(item => item.id)) + 1;
  }

  // Inventory Management
  getInventory(): InventoryItem[] {
    return this.loadFromStorage('inventory', inventoryData as InventoryItem[]);
  }

  saveInventoryItem(item: Omit<InventoryItem, 'id' | 'createdAt'>): InventoryItem {
    const items = this.getInventory();
    const newItem: InventoryItem = {
      ...item,
      id: this.getNextId(items),
      createdAt: new Date().toISOString()
    };
    items.push(newItem);
    this.saveToStorage('inventory', items);
    return newItem;
  }

  updateInventoryItem(id: number, updates: Partial<InventoryItem>): InventoryItem | null {
    const items = this.getInventory();
    const index = items.findIndex(item => item.id === id);
    if (index === -1) return null;
    
    items[index] = { ...items[index], ...updates };
    this.saveToStorage('inventory', items);
    return items[index];
  }

  deleteInventoryItem(id: number): boolean {
    const items = this.getInventory();
    const filteredItems = items.filter(item => item.id !== id);
    if (filteredItems.length === items.length) return false;
    
    this.saveToStorage('inventory', filteredItems);
    return true;
  }

  // Inventory Types Management
  getInventoryTypes(): InventoryType[] {
    return this.loadFromStorage('inventoryTypes', inventoryTypesData as InventoryType[]);
  }

  saveInventoryType(type: Omit<InventoryType, 'id'>): InventoryType {
    const types = this.getInventoryTypes();
    const newType: InventoryType = {
      ...type,
      id: this.getNextId(types)
    };
    types.push(newType);
    this.saveToStorage('inventoryTypes', types);
    return newType;
  }

  updateInventoryType(id: number, updates: Partial<InventoryType>): InventoryType | null {
    const types = this.getInventoryTypes();
    const index = types.findIndex(type => type.id === id);
    if (index === -1) return null;
    
    types[index] = { ...types[index], ...updates };
    this.saveToStorage('inventoryTypes', types);
    return types[index];
  }

  deleteInventoryType(id: number): boolean {
    const types = this.getInventoryTypes();
    const filteredTypes = types.filter(type => type.id !== id);
    if (filteredTypes.length === types.length) return false;
    
    this.saveToStorage('inventoryTypes', filteredTypes);
    return true;
  }

  // Package Types Management
  getPackageTypes(): PackageType[] {
    return this.loadFromStorage('packageTypes', packageTypesData as PackageType[]);
  }

  savePackageType(type: Omit<PackageType, 'id'>): PackageType {
    const types = this.getPackageTypes();
    const newType: PackageType = {
      ...type,
      id: this.getNextId(types)
    };
    types.push(newType);
    this.saveToStorage('packageTypes', types);
    return newType;
  }

  updatePackageType(id: number, updates: Partial<PackageType>): PackageType | null {
    const types = this.getPackageTypes();
    const index = types.findIndex(type => type.id === id);
    if (index === -1) return null;
    
    types[index] = { ...types[index], ...updates };
    this.saveToStorage('packageTypes', types);
    return types[index];
  }

  deletePackageType(id: number): boolean {
    const types = this.getPackageTypes();
    const filteredTypes = types.filter(type => type.id !== id);
    if (filteredTypes.length === types.length) return false;
    
    this.saveToStorage('packageTypes', filteredTypes);
    return true;
  }

  // Suppliers Management
  getSuppliers(): Supplier[] {
    return this.loadFromStorage('suppliers', suppliersData as Supplier[]);
  }

  saveSupplier(supplier: Omit<Supplier, 'id' | 'createdAt'>): Supplier {
    const suppliers = this.getSuppliers();
    const newSupplier: Supplier = {
      ...supplier,
      id: this.getNextId(suppliers),
      createdAt: new Date().toISOString()
    };
    suppliers.push(newSupplier);
    this.saveToStorage('suppliers', suppliers);
    return newSupplier;
  }

  updateSupplier(id: number, updates: Partial<Supplier>): Supplier | null {
    const suppliers = this.getSuppliers();
    const index = suppliers.findIndex(supplier => supplier.id === id);
    if (index === -1) return null;
    
    suppliers[index] = { ...suppliers[index], ...updates };
    this.saveToStorage('suppliers', suppliers);
    return suppliers[index];
  }

  deleteSupplier(id: number): boolean {
    const suppliers = this.getSuppliers();
    const filteredSuppliers = suppliers.filter(supplier => supplier.id !== id);
    if (filteredSuppliers.length === suppliers.length) return false;
    
    this.saveToStorage('suppliers', filteredSuppliers);
    return true;
  }

  // Customers Management
  getCustomers(): Customer[] {
    return this.loadFromStorage('customers', customersData as Customer[]);
  }

  saveCustomer(customer: Omit<Customer, 'id' | 'createdAt'>): Customer {
    const customers = this.getCustomers();
    const newCustomer: Customer = {
      ...customer,
      id: this.getNextId(customers),
      deliveryLocations: customer.deliveryLocations.map((loc, index) => ({
        ...loc,
        id: index + 1
      })),
      createdAt: new Date().toISOString()
    };
    customers.push(newCustomer);
    this.saveToStorage('customers', customers);
    return newCustomer;
  }

  updateCustomer(id: number, updates: Partial<Customer>): Customer | null {
    const customers = this.getCustomers();
    const index = customers.findIndex(customer => customer.id === id);
    if (index === -1) return null;
    
    customers[index] = { ...customers[index], ...updates };
    this.saveToStorage('customers', customers);
    return customers[index];
  }

  deleteCustomer(id: number): boolean {
    const customers = this.getCustomers();
    const filteredCustomers = customers.filter(customer => customer.id !== id);
    if (filteredCustomers.length === customers.length) return false;
    
    this.saveToStorage('customers', filteredCustomers);
    return true;
  }

  // Configuration Management
  getConfig(): Config {
    try {
      const stored = localStorage.getItem(this.getStorageKey('config'));
      return stored ? JSON.parse(stored) : configData as Config;
    } catch {
      return configData as Config;
    }
  }

  updateConfig(updates: Partial<Config>): Config {
    const config = this.getConfig();
    const updatedConfig = { ...config, ...updates };
    try {
      localStorage.setItem(this.getStorageKey('config'), JSON.stringify(updatedConfig));
    } catch (error) {
      console.error('Failed to save config to localStorage:', error);
    }
    return updatedConfig;
  }

  // Order Number Generation
  generateOrderNumber(type: 'purchase' | 'sales'): string {
    const config = this.getConfig();
    const orderConfig = type === 'purchase' ? config.purchaseOrders : config.salesOrders;
    
    const currentNumber = orderConfig.startCounter;
    const newConfig = {
      ...config,
      [type === 'purchase' ? 'purchaseOrders' : 'salesOrders']: {
        ...orderConfig,
        startCounter: currentNumber + 1
      }
    };
    
    this.updateConfig(newConfig);
    
    return `${orderConfig.prefix}${currentNumber.toString().padStart(5, '0')}`;
  }

  // General Settings
  getGeneralSettings() {
    return this.loadFromStorage('generalSettings', {
      companyName: 'Acme Corp Warehouse',
      address: '123 Warehouse Street, Industrial District',
      phone: '+1-555-0123',
      email: 'info@acmecorp.com',
      website: 'https://acmecorp.com',
      language: 'en',
      currency: 'USD',
      timezone: 'UTC'
    });
  }

  updateGeneralSettings(settings: any) {
    this.saveToStorage('generalSettings', settings);
    return settings;
  }

  // Warehouse Layout with Location ID System and Path-Based Uniqueness
  getWarehouseLayout() {
    // Check if we have old format data and migrate it
    const existingData = this.loadFromStorage('warehouseLayout', null);
    if (existingData && Array.isArray(existingData)) {
      // Old format detected, clear and use new format
      localStorage.removeItem(this.getStorageKey('warehouseLayout'));
    }
    
    return this.loadFromStorage('warehouseLayout', {
      zones: [
        { id: "zone-A", zoneId: "A", name: "Electronics" },
        { id: "zone-B", zoneId: "B", name: "Medical Supplies" }
      ],
      aisles: [
        { id: "aisle-A1", zoneId: "A", aisleId: "1", name: "Main Electronics" },
        { id: "aisle-A2", zoneId: "A", aisleId: "2", name: "Mobile Devices" },
        { id: "aisle-B1", zoneId: "B", aisleId: "1", name: "Emergency Supplies" }
      ],
      shelves: [
        { id: "shelf-A1-1", zoneId: "A", aisleId: "1", shelfId: "1", name: "Computers" },
        { id: "shelf-A1-2", zoneId: "A", aisleId: "1", shelfId: "2", name: "Accessories" },
        { id: "shelf-A2-1", zoneId: "A", aisleId: "2", shelfId: "1", name: "Phones" },
        { id: "shelf-B1-1", zoneId: "B", aisleId: "1", shelfId: "1", name: "First Aid" }
      ],
      bins: [
        {
          id: "bin-A1-1-1", zoneId: "A", aisleId: "1", shelfId: "1",
          binId: "1", name: "Front Left", capacity: 1.0
        },
        {
          id: "bin-A1-1-2", zoneId: "A", aisleId: "1", shelfId: "1",
          binId: "2", name: "Front Right", capacity: 0.5
        },
        {
          id: "bin-A1-2-1", zoneId: "A", aisleId: "1", shelfId: "2",
          binId: "1", name: "Middle", capacity: 0.7
        },
        {
          id: "bin-A2-1-1", zoneId: "A", aisleId: "2", shelfId: "1",
          binId: "1", name: "Back Bin", capacity: 1.2
        },
        {
          id: "bin-B1-1-1", zoneId: "B", aisleId: "1", shelfId: "1",
          binId: "1", name: "Sterile Area", capacity: 0.8
        }
      ]
    });
  }

  saveWarehouseLayout(layout: any) {
    this.saveToStorage('warehouseLayout', layout);
    return layout;
  }

  // Path-Based Location ID Generation Helper
  generateLocationId(zoneId: string, aisleId?: string, shelfId?: string, binId?: string): string {
    let locationId = zoneId;
    if (aisleId !== undefined) locationId += `.${aisleId}`;
    if (shelfId !== undefined) locationId += `.${shelfId}`;
    if (binId !== undefined) locationId += `.${binId}`;
    return locationId;
  }

  // Path-Based Uniqueness Validation
  validateWarehousePathUniqueness(type: string, zoneId: string, aisleId?: string, shelfId?: string, binId?: string, existingId?: string): { isValid: boolean, error?: string } {
    const layout = this.getWarehouseLayout();
    const fullPath = this.generateLocationId(zoneId, aisleId, shelfId, binId);
    
    let exists = false;
    
    if (type === 'zone') {
      exists = layout.zones.some(z => z.zoneId === zoneId && z.id !== existingId);
    } else if (type === 'aisle') {
      exists = layout.aisles.some(a => a.zoneId === zoneId && a.aisleId === aisleId && a.id !== existingId);
    } else if (type === 'shelf') {
      exists = layout.shelves.some(s => s.zoneId === zoneId && s.aisleId === aisleId && s.shelfId === shelfId && s.id !== existingId);
    } else if (type === 'bin') {
      exists = layout.bins.some(b => b.zoneId === zoneId && b.aisleId === aisleId && b.shelfId === shelfId && b.binId === binId && b.id !== existingId);
    }
    
    if (exists) {
      let errorMsg = '';
      if (type === 'zone') {
        errorMsg = `Zone ID "${zoneId}" already exists. Zone IDs must be unique.`;
      } else if (type === 'aisle') {
        errorMsg = `Aisle ${fullPath} already exists. Please choose a different Aisle ID.`;
      } else if (type === 'shelf') {
        errorMsg = `Shelf ${fullPath} already exists. Please choose a different Shelf ID.`;
      } else if (type === 'bin') {
        errorMsg = `Bin ${fullPath} already exists. Please choose a different Bin ID.`;
      }
      return {
        isValid: false,
        error: errorMsg
      };
    }
    
    return { isValid: true };
  }

  // Check if parent exists
  validateWarehouseParentExists(type: string, zoneId: string, aisleId?: string, shelfId?: string): { isValid: boolean, error?: string } {
    const layout = this.getWarehouseLayout();
    
    if (type === 'aisle') {
      const zoneExists = layout.zones.some(z => z.zoneId === zoneId);
      if (!zoneExists) {
        return { isValid: false, error: `Zone ${zoneId} does not exist. Please create the zone first.` };
      }
    } else if (type === 'shelf') {
      const aisleExists = layout.aisles.some(a => a.zoneId === zoneId && a.aisleId === aisleId);
      if (!aisleExists) {
        return { isValid: false, error: `Aisle ${zoneId}.${aisleId} does not exist. Please create the aisle first.` };
      }
    } else if (type === 'bin') {
      const shelfExists = layout.shelves.some(s => s.zoneId === zoneId && s.aisleId === aisleId && s.shelfId === shelfId);
      if (!shelfExists) {
        return { isValid: false, error: `Shelf ${zoneId}.${aisleId}.${shelfId} does not exist. Please create the shelf first.` };
      }
    }
    
    return { isValid: true };
  }

  // Check if element has children
  hasWarehouseChildren(type: string, zoneId: string, aisleId?: string, shelfId?: string): { hasChildren: boolean, childType?: string, count?: number } {
    const layout = this.getWarehouseLayout();
    
    if (type === 'zone') {
      const aisles = layout.aisles.filter(a => a.zoneId === zoneId);
      return { hasChildren: aisles.length > 0, childType: 'aisle', count: aisles.length };
    } else if (type === 'aisle') {
      const shelves = layout.shelves.filter(s => s.zoneId === zoneId && s.aisleId === aisleId);
      return { hasChildren: shelves.length > 0, childType: 'shelf', count: shelves.length };
    } else if (type === 'shelf') {
      const bins = layout.bins.filter(b => b.zoneId === zoneId && b.aisleId === aisleId && b.shelfId === shelfId);
      return { hasChildren: bins.length > 0, childType: 'bin', count: bins.length };
    }
    
    return { hasChildren: false };
  }

  // Helper function to get warehouse hierarchy for UI
  getWarehouseHierarchy() {
    const layout = this.getWarehouseLayout();
    
    // Ensure layout has the correct structure
    if (!layout || !layout.zones || !Array.isArray(layout.zones)) {
      console.warn('Warehouse layout is invalid, reinitializing...');
      // Clear the invalid data and reload default
      localStorage.removeItem(this.getStorageKey('warehouseLayout'));
      const freshLayout = this.getWarehouseLayout();
      return this.buildHierarchy(freshLayout);
    }
    
    return this.buildHierarchy(layout);
  }

  private buildHierarchy(layout: any) {
    return layout.zones.map((zone: any) => ({
      ...zone,
      aisles: layout.aisles
        .filter((aisle: any) => aisle.zoneId === zone.zoneId)
        .map((aisle: any) => ({
          ...aisle,
          shelves: layout.shelves
            .filter((shelf: any) => shelf.zoneId === aisle.zoneId && shelf.aisleId === aisle.aisleId)
            .map((shelf: any) => ({
              ...shelf,
              bins: layout.bins.filter((bin: any) => 
                bin.zoneId === shelf.zoneId && 
                bin.aisleId === shelf.aisleId && 
                bin.shelfId === shelf.shelfId
              )
            }))
        }))
    }));
  }

  // Warehouse Management Functions with Path-Based Uniqueness
  addZone(zoneId: string, name: string) {
    const validation = this.validateWarehousePathUniqueness('zone', zoneId);
    if (!validation.isValid) {
      throw new Error(validation.error);
    }

    const layout = this.getWarehouseLayout();
    const newZone = {
      id: `zone-${zoneId}`,
      zoneId,
      name
    };
    layout.zones.push(newZone);
    this.saveWarehouseLayout(layout);
    return newZone;
  }

  updateZone(zoneId: string, name: string) {
    const layout = this.getWarehouseLayout();
    const zone = layout.zones.find((z: any) => z.zoneId === zoneId);
    if (zone) {
      zone.name = name;
      this.saveWarehouseLayout(layout);
      return zone;
    }
    return null;
  }

  deleteZone(zoneId: string) {
    const childCheck = this.hasWarehouseChildren('zone', zoneId);
    if (childCheck.hasChildren) {
      throw new Error(`Cannot delete Zone ${zoneId} because it contains ${childCheck.count} ${childCheck.childType}${childCheck.count !== 1 ? 's' : ''}.`);
    }

    const layout = this.getWarehouseLayout();
    layout.zones = layout.zones.filter((z: any) => z.zoneId !== zoneId);
    this.saveWarehouseLayout(layout);
    return true;
  }

  addAisle(zoneId: string, aisleId: string, name: string) {
    const parentValidation = this.validateWarehouseParentExists('aisle', zoneId);
    if (!parentValidation.isValid) {
      throw new Error(parentValidation.error);
    }

    const validation = this.validateWarehousePathUniqueness('aisle', zoneId, aisleId);
    if (!validation.isValid) {
      throw new Error(validation.error);
    }

    const layout = this.getWarehouseLayout();
    const newAisle = {
      id: `aisle-${zoneId}${aisleId}`,
      zoneId,
      aisleId,
      name
    };
    layout.aisles.push(newAisle);
    this.saveWarehouseLayout(layout);
    return newAisle;
  }

  updateAisle(zoneId: string, aisleId: string, name: string) {
    const layout = this.getWarehouseLayout();
    const aisle = layout.aisles.find((a: any) => a.zoneId === zoneId && a.aisleId === aisleId);
    if (aisle) {
      aisle.name = name;
      this.saveWarehouseLayout(layout);
      return aisle;
    }
    return null;
  }

  deleteAisle(zoneId: string, aisleId: string) {
    const childCheck = this.hasWarehouseChildren('aisle', zoneId, aisleId);
    if (childCheck.hasChildren) {
      throw new Error(`Cannot delete Aisle ${zoneId}.${aisleId} because it contains ${childCheck.count} ${childCheck.childType}${childCheck.count !== 1 ? 's' : ''}.`);
    }

    const layout = this.getWarehouseLayout();
    layout.aisles = layout.aisles.filter((a: any) => !(a.zoneId === zoneId && a.aisleId === aisleId));
    this.saveWarehouseLayout(layout);
    return true;
  }

  addShelf(zoneId: string, aisleId: string, shelfId: string, name: string) {
    const parentValidation = this.validateWarehouseParentExists('shelf', zoneId, aisleId);
    if (!parentValidation.isValid) {
      throw new Error(parentValidation.error);
    }

    const validation = this.validateWarehousePathUniqueness('shelf', zoneId, aisleId, shelfId);
    if (!validation.isValid) {
      throw new Error(validation.error);
    }

    const layout = this.getWarehouseLayout();
    const newShelf = {
      id: `shelf-${zoneId}${aisleId}-${shelfId}`,
      zoneId,
      aisleId,
      shelfId,
      name
    };
    layout.shelves.push(newShelf);
    this.saveWarehouseLayout(layout);
    return newShelf;
  }

  updateShelf(zoneId: string, aisleId: string, shelfId: string, name: string) {
    const layout = this.getWarehouseLayout();
    const shelf = layout.shelves.find((s: any) => s.zoneId === zoneId && s.aisleId === aisleId && s.shelfId === shelfId);
    if (shelf) {
      shelf.name = name;
      this.saveWarehouseLayout(layout);
      return shelf;
    }
    return null;
  }

  deleteShelf(zoneId: string, aisleId: string, shelfId: string) {
    const childCheck = this.hasWarehouseChildren('shelf', zoneId, aisleId, shelfId);
    if (childCheck.hasChildren) {
      throw new Error(`Cannot delete Shelf ${zoneId}.${aisleId}.${shelfId} because it contains ${childCheck.count} ${childCheck.childType}${childCheck.count !== 1 ? 's' : ''}.`);
    }

    const layout = this.getWarehouseLayout();
    layout.shelves = layout.shelves.filter((s: any) => !(s.zoneId === zoneId && s.aisleId === aisleId && s.shelfId === shelfId));
    this.saveWarehouseLayout(layout);
    return true;
  }

  addBin(zoneId: string, aisleId: string, shelfId: string, binId: string, name: string, capacity: number) {
    const parentValidation = this.validateWarehouseParentExists('bin', zoneId, aisleId, shelfId);
    if (!parentValidation.isValid) {
      throw new Error(parentValidation.error);
    }

    const validation = this.validateWarehousePathUniqueness('bin', zoneId, aisleId, shelfId, binId);
    if (!validation.isValid) {
      throw new Error(validation.error);
    }

    const layout = this.getWarehouseLayout();
    const newBin = {
      id: `bin-${zoneId}${aisleId}-${shelfId}-${binId}`,
      zoneId,
      aisleId,
      shelfId,
      binId,
      name,
      capacity
    };
    layout.bins.push(newBin);
    this.saveWarehouseLayout(layout);
    return newBin;
  }

  updateBin(zoneId: string, aisleId: string, shelfId: string, binId: string, name: string, capacity: number) {
    const layout = this.getWarehouseLayout();
    const bin = layout.bins.find((b: any) => b.zoneId === zoneId && b.aisleId === aisleId && b.shelfId === shelfId && b.binId === binId);
    if (bin) {
      bin.name = name;
      bin.capacity = capacity;
      this.saveWarehouseLayout(layout);
      return bin;
    }
    return null;
  }

  deleteBin(zoneId: string, aisleId: string, shelfId: string, binId: string) {
    const layout = this.getWarehouseLayout();
    layout.bins = layout.bins.filter((b: any) => !(b.zoneId === zoneId && b.aisleId === aisleId && b.shelfId === shelfId && b.binId === binId));
    this.saveWarehouseLayout(layout);
    return true;
  }

  // SMTP Settings
  getSMTPSettings() {
    return this.loadFromStorage('smtpSettings', {
      host: '',
      port: 587,
      username: '',
      password: '',
      senderEmail: '',
      secure: false
    });
  }

  updateSMTPSettings(settings: any) {
    this.saveToStorage('smtpSettings', settings);
    return settings;
  }

  // API Settings
  getAPISettings() {
    return this.loadFromStorage('apiSettings', {
      inbound: [
        {
          name: 'Inventory Updates',
          description: 'Receive inventory level updates from external systems',
          endpoint: '/api/inventory/update',
          method: 'POST',
          samplePayload: {
            sku: 'ITEM001',
            quantity: 100,
            location: 'A1-01-001'
          }
        },
        {
          name: 'Order Creation',
          description: 'Create new orders from external systems',
          endpoint: '/api/orders/create',
          method: 'POST',
          samplePayload: {
            customerCode: 'CUST001',
            items: [{ sku: 'ITEM001', quantity: 10 }]
          }
        }
      ],
      outbound: []
    });
  }

  updateAPISettings(settings: any) {
    this.saveToStorage('apiSettings', settings);
    return settings;
  }

  // Backup/Restore
  exportAllData() {
    const allData = {
      inventory: this.getInventory(),
      inventoryTypes: this.getInventoryTypes(),
      packageTypes: this.getPackageTypes(),
      suppliers: this.getSuppliers(),
      customers: this.getCustomers(),
      config: this.getConfig(),
      generalSettings: this.getGeneralSettings(),
      warehouseLayout: this.getWarehouseLayout(),
      smtpSettings: this.getSMTPSettings(),
      apiSettings: this.getAPISettings()
    };
    
    const dataStr = JSON.stringify(allData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `wms-backup-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  }

  importAllData(jsonData: any) {
    try {
      if (jsonData.inventory) this.saveToStorage('inventory', jsonData.inventory);
      if (jsonData.inventoryTypes) this.saveToStorage('inventoryTypes', jsonData.inventoryTypes);
      if (jsonData.packageTypes) this.saveToStorage('packageTypes', jsonData.packageTypes);
      if (jsonData.suppliers) this.saveToStorage('suppliers', jsonData.suppliers);
      if (jsonData.customers) this.saveToStorage('customers', jsonData.customers);
      if (jsonData.config) this.saveToStorage('config', jsonData.config);
      if (jsonData.generalSettings) this.saveToStorage('generalSettings', jsonData.generalSettings);
      if (jsonData.warehouseLayout) this.saveToStorage('warehouseLayout', jsonData.warehouseLayout);
      if (jsonData.smtpSettings) this.saveToStorage('smtpSettings', jsonData.smtpSettings);
      if (jsonData.apiSettings) this.saveToStorage('apiSettings', jsonData.apiSettings);
      return true;
    } catch (error) {
      console.error('Import failed:', error);
      return false;
    }
  }
}

export const dataManager = new DataManager();