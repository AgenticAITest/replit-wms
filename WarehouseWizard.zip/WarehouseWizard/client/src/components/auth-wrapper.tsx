import { ReactNode, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/auth-context";
import { MainLayout } from "@/components/layout/main-layout";

interface AuthWrapperProps {
  children: ReactNode;
}

export function AuthWrapper({ children }: AuthWrapperProps) {
  const { isAuthenticated } = useAuth();
  const [location, setLocation] = useLocation();

  useEffect(() => {
    // If not authenticated and not on login page, redirect to login
    if (!isAuthenticated && location !== "/login") {
      setLocation("/login");
    }
    // If authenticated and on login page, redirect to dashboard
    else if (isAuthenticated && location === "/login") {
      setLocation("/");
    }
  }, [isAuthenticated, location, setLocation]);

  // If on login page, render without layout
  if (location === "/login") {
    return <>{children}</>;
  }

  // If not authenticated, don't render anything (will redirect via useEffect)
  if (!isAuthenticated) {
    return null;
  }

  // If authenticated, render with main layout
  return <MainLayout>{children}</MainLayout>;
}