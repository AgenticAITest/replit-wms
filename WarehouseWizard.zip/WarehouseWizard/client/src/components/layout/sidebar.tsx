import { Link, useLocation } from "wouter";
import { 
  BarChart3, 
  Package, 
  Truck, 
  Warehouse, 
  GitBranch, 
  Users, 
  FileBarChart, 
  Settings, 
  Building, 
  Globe,
  ShoppingCart,
  ClipboardList,
  ScanLine,
  CheckSquare,
  DollarSign
} from "lucide-react";
import { useAuth } from "@/contexts/auth-context";
import { useTenant } from "@/contexts/tenant-context";
import { useRole, type UserRole } from "@/contexts/role-context";
import { usePermissions } from "@/contexts/permission-context";
import { useLanguage } from "@/contexts/language-context";
import { useTenants } from "@/hooks/use-tenant";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { useEffect } from "react";

export function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const { currentTenant, setCurrentTenant, availableTenants, setAvailableTenants } = useTenant();
  const { currentRole } = useRole();
  const { canAccess } = usePermissions();
  const { t } = useLanguage();
  const { data: tenants, isLoading: tenantsLoading } = useTenants();

  useEffect(() => {
    if (tenants && tenants.length > 0) {
      setAvailableTenants(tenants);
      if (!currentTenant) {
        setCurrentTenant(tenants[0]);
      }
    }
  }, [tenants, currentTenant, setCurrentTenant, setAvailableTenants]);

  // Permission-based navigation items
  const getNavigationItems = () => {
    const allItems = [
      { resource: "dashboard", path: "/", label: t("nav.dashboard"), icon: BarChart3 },
      { resource: "inventory", path: "/inventory", label: t("nav.inventory"), icon: Package },
      { resource: "warehouse", path: "/warehouse", label: t("nav.warehouse"), icon: Warehouse },
      { resource: "purchaseOrders", path: "/purchase-orders", label: t("nav.purchaseOrders"), icon: ShoppingCart },
      { resource: "salesOrders", path: "/sales-orders", label: t("nav.salesOrders"), icon: Truck },
      { resource: "workflow", path: "/workflow", label: t("nav.workflow"), icon: GitBranch },
      { resource: "users", path: "/users", label: t("nav.users"), icon: Users },
      { resource: "reports", path: "/reports", label: t("nav.reports"), icon: FileBarChart },
      { resource: "settings", path: "/settings", label: "Settings", icon: Settings },
      { resource: "myTasks", path: "/my-tasks", label: t("nav.myTasks"), icon: ClipboardList },
      { resource: "scanItems", path: "/scan-items", label: t("nav.scanItems"), icon: ScanLine },
      { resource: "updateStatus", path: "/update-status", label: t("nav.updateStatus"), icon: CheckSquare },
      { resource: "financialReports", path: "/financial-reports", label: t("nav.financialReports"), icon: DollarSign },
    ];

    // Filter items based on permissions
    return allItems.filter(item => canAccess(item.resource));
  };

  const navigationItems = getNavigationItems();

  return (
    <aside className="w-64 bg-[#1E3A8A] shadow-lg border-r border-blue-800 flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-blue-700">
        <div className="flex items-center mb-4">
          <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center mr-3">
            <Warehouse className="w-4 h-4 text-blue-600" />
          </div>
          <h1 className="text-xl font-semibold text-white">WMS Pro</h1>
        </div>
        
        {/* Tenant Selector */}
        <Select
          value={currentTenant?.id.toString()}
          onValueChange={(value) => {
            const tenant = availableTenants.find(t => t.id.toString() === value);
            if (tenant) setCurrentTenant(tenant);
          }}
          disabled={tenantsLoading}
        >
          <SelectTrigger className="w-full bg-blue-700 border-blue-600 text-white">
            <SelectValue placeholder="Select tenant..." />
          </SelectTrigger>
          <SelectContent>
            {availableTenants.map((tenant) => (
              <SelectItem key={tenant.id} value={tenant.id.toString()}>
                {tenant.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            
            return (
              <li key={item.path}>
                <Link href={item.path}>
                  <div className={`sidebar-item flex items-center p-3 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                    isActive 
                      ? "active bg-white text-blue-600" 
                      : "text-blue-100 hover:bg-blue-700 hover:text-white"
                  }`}>
                    <Icon className="w-5 h-5 mr-3" />
                    {item.label}
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t border-blue-700">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Avatar className="w-10 h-10 mr-3">
              <AvatarFallback className="bg-white text-blue-600">
                {user?.firstName?.[0]}{user?.lastName?.[0]}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="text-sm font-medium text-white">
                {user?.firstName} {user?.lastName}
              </div>
              <div className="text-xs text-blue-200 capitalize">
                {t(`role.${currentRole}`)}
              </div>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={logout}
            className="text-blue-200 hover:text-white hover:bg-blue-700"
          >
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </aside>
  );
}
