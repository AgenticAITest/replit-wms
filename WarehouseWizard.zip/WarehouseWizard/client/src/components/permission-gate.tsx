import { ReactNode } from "react";
import { usePermissions } from "@/contexts/permission-context";
import { Permission } from "@/lib/permissions";

interface PermissionGateProps {
  resource: string;
  action?: Permission;
  children: ReactNode;
  fallback?: ReactNode;
}

export function PermissionGate({ 
  resource, 
  action = "VIEW", 
  children, 
  fallback = null 
}: PermissionGateProps) {
  const { hasPermission } = usePermissions();

  if (!hasPermission(resource, action)) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
}