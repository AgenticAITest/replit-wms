import { Shield, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { usePermissions } from "@/contexts/permission-context";

export function AccessDenied() {
  const [, setLocation] = useLocation();
  const { currentRole } = usePermissions();

  const handleGoBack = () => {
    // Navigate to dashboard or first accessible page
    setLocation("/");
  };

  return (
    <div className="flex items-center justify-center min-h-96">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-red-100 rounded-full">
              <Shield className="h-8 w-8 text-red-600" />
            </div>
          </div>
          <CardTitle className="text-xl">Access Denied</CardTitle>
          <CardDescription>
            Your current role ({currentRole}) doesn't have permission to access this page.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <p className="text-sm text-gray-600 mb-6">
            Please contact your administrator if you need access to this feature.
          </p>
          <Button onClick={handleGoBack} variant="outline" className="w-full">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Go Back
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}