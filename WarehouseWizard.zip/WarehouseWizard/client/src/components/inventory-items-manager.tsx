import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Edit, Trash2, Package } from "lucide-react";
import { dataManager, type InventoryItem } from "@/lib/data-manager";
import { useToast } from "@/hooks/use-toast";

export default function InventoryItemsManager() {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [inventoryTypes, setInventoryTypes] = useState<any[]>([]);
  const [packageTypes, setPackageTypes] = useState<any[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [formData, setFormData] = useState({
    sku: "",
    itemName: "",
    inventoryType: "",
    packageType: "",
    size: "",
    weight: "",
    minimumStockLevel: 0,
    hasExpiry: false,
    expiryDate: "",
    tenantId: 1,
    active: true
  });
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setItems(dataManager.getInventory());
    // Filter to only show active types for dropdowns
    setInventoryTypes(dataManager.getInventoryTypes().filter(type => type.active));
    setPackageTypes(dataManager.getPackageTypes().filter(type => type.active));
  };

  const handleSave = () => {
    try {
      if (editingItem) {
        const updated = dataManager.updateInventoryItem(editingItem.id, formData);
        if (updated) {
          toast({
            title: "Success",
            description: "Inventory item updated successfully"
          });
        }
      } else {
        dataManager.saveInventoryItem(formData);
        toast({
          title: "Success",
          description: "Inventory item added successfully"
        });
      }
      loadData();
      resetForm();
      setIsDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save inventory item",
        variant: "destructive"
      });
    }
  };

  const handleEdit = (item: InventoryItem) => {
    setEditingItem(item);
    setFormData({
      sku: item.sku,
      itemName: item.itemName,
      inventoryType: item.inventoryType,
      packageType: item.packageType,
      size: item.size,
      weight: item.weight,
      minimumStockLevel: item.minimumStockLevel,
      hasExpiry: item.hasExpiry,
      expiryDate: item.expiryDate || "",
      tenantId: item.tenantId,
      active: item.active
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (item: InventoryItem) => {
    // Business logic: only allow deletion if current stock = 0
    const currentStock = item.currentStock || 0;
    
    if (currentStock > 0) {
      toast({
        title: "Cannot Delete",
        description: `Cannot delete item with current stock of ${currentStock}. Stock must be 0 to delete.`,
        variant: "destructive"
      });
      return;
    }

    if (confirm("Are you sure you want to delete this inventory item?")) {
      const success = dataManager.deleteInventoryItem(item.id);
      if (success) {
        toast({
          title: "Success",
          description: "Inventory item deleted successfully"
        });
        loadData();
      } else {
        toast({
          title: "Error",
          description: "Failed to delete inventory item",
          variant: "destructive"
        });
      }
    }
  };

  const resetForm = () => {
    setFormData({
      sku: "",
      itemName: "",
      inventoryType: "",
      packageType: "",
      size: "",
      weight: "",
      minimumStockLevel: 0,
      hasExpiry: false,
      expiryDate: "",
      tenantId: 1,
      active: true
    });
    setEditingItem(null);
  };

  const openAddDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">Inventory Items</h3>
          <p className="text-sm text-gray-600">Manage your inventory master data</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openAddDialog}>
              <Plus className="h-4 w-4 mr-2" />
              Add Inventory Item
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingItem ? "Edit Inventory Item" : "Add New Inventory Item"}
              </DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="sku">SKU *</Label>
                  <Input
                    id="sku"
                    value={formData.sku}
                    onChange={(e) => setFormData({...formData, sku: e.target.value})}
                    placeholder="Enter SKU"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="itemName">Item Name *</Label>
                  <Input
                    id="itemName"
                    value={formData.itemName}
                    onChange={(e) => setFormData({...formData, itemName: e.target.value})}
                    placeholder="Enter item name"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="inventoryType">Inventory Type</Label>
                  <Select value={formData.inventoryType} onValueChange={(value) => setFormData({...formData, inventoryType: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {inventoryTypes.map((type: any) => (
                        <SelectItem key={type.id} value={type.name}>{type.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="packageType">Package Type</Label>
                  <Select value={formData.packageType} onValueChange={(value) => setFormData({...formData, packageType: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select package type" />
                    </SelectTrigger>
                    <SelectContent>
                      {packageTypes.map((type: any) => (
                        <SelectItem key={type.id} value={type.name}>{type.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="size">Size (m³)</Label>
                  <Input
                    id="size"
                    value={formData.size}
                    onChange={(e) => setFormData({...formData, size: e.target.value})}
                    placeholder="1.5"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                    id="weight"
                    value={formData.weight}
                    onChange={(e) => setFormData({...formData, weight: e.target.value})}
                    placeholder="2.5"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="minimumStockLevel">Min Stock Level</Label>
                  <Input
                    id="minimumStockLevel"
                    type="number"
                    value={formData.minimumStockLevel}
                    onChange={(e) => setFormData({...formData, minimumStockLevel: parseInt(e.target.value) || 0})}
                    placeholder="0"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="active"
                    checked={formData.active}
                    onCheckedChange={(checked) => setFormData({...formData, active: checked})}
                  />
                  <Label htmlFor="active">Active</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="hasExpiry"
                    checked={formData.hasExpiry}
                    onCheckedChange={(checked) => setFormData({...formData, hasExpiry: checked})}
                  />
                  <Label htmlFor="hasExpiry">Has Expiry Date</Label>
                </div>

                {formData.hasExpiry && (
                  <div className="space-y-2">
                    <Label htmlFor="expiryDate">Expiry Date</Label>
                    <Input
                      id="expiryDate"
                      type="date"
                      value={formData.expiryDate}
                      onChange={(e) => setFormData({...formData, expiryDate: e.target.value})}
                    />
                  </div>
                )}
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSave}>
                  {editingItem ? "Update" : "Add"} Item
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>SKU</TableHead>
                <TableHead>Item Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Package</TableHead>
                <TableHead>Size/Weight</TableHead>
                <TableHead>Min Stock</TableHead>
                <TableHead>Expiry</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-gray-500">
                    No inventory items found. Add your first item to get started.
                  </TableCell>
                </TableRow>
              ) : (
                items.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.sku}</TableCell>
                    <TableCell>{item.itemName}</TableCell>
                    <TableCell>{item.inventoryType}</TableCell>
                    <TableCell>{item.packageType}</TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>{item.size}</div>
                        <div className="text-gray-500">{item.weight}</div>
                      </div>
                    </TableCell>
                    <TableCell>{item.minimumStockLevel}</TableCell>
                    <TableCell>
                      {item.hasExpiry ? (
                        <Badge variant="secondary">{item.expiryDate}</Badge>
                      ) : (
                        <Badge variant="outline">No Expiry</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant={item.active ? "default" : "secondary"}>
                        {item.active ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(item)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(item)}
                          disabled={!!(item.currentStock && item.currentStock > 0)}
                          className={item.currentStock && item.currentStock > 0 ? "opacity-50 cursor-not-allowed" : ""}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}