import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Download, Eye, Edit, ChevronLeft, ChevronRight } from "lucide-react";
import { useTenant } from "@/contexts/tenant-context";
import { Order } from "@shared/schema";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export function RecentOrders() {
  const { currentTenant } = useTenant();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  
  const { data: orders, isLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders/tenant", currentTenant?.id],
    enabled: !!currentTenant?.id,
  });

  const handleExport = () => {
    toast({
      title: "Export Started",
      description: "You will receive an email when the export is ready.",
    });
  };

  const handleSearch = (value: string) => {
    setSearchTerm(value);
    if (value.length > 2) {
      toast({
        title: "Searching",
        description: `Searching for "${value}"...`,
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "processing":
        return "bg-yellow-100 text-yellow-800";
      case "packed":
        return "bg-blue-100 text-blue-800";
      case "shipped":
        return "bg-green-100 text-green-800";
      case "delivered":
        return "bg-green-100 text-green-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
      case "urgent":
        return "bg-red-100 text-red-800";
      case "medium":
        return "bg-blue-100 text-blue-800";
      case "low":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Less than 1 hour ago";
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} day${diffInDays > 1 ? 's' : ''} ago`;
  };

  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
      <CardHeader className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-800">Recent Orders</h3>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search orders..."
                className="pl-10 w-64"
                value={searchTerm}
                onChange={(e) => handleSearch(e.target.value)}
              />
            </div>
            <Button onClick={handleExport} className="bg-blue-600 hover:bg-blue-700">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Order ID</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Customer</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Items</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Status</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Priority</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Created</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {orders?.slice(0, 10).map((order) => (
                <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                  <td className="p-4">
                    <span className="font-mono text-sm text-blue-600">
                      {order.orderNumber}
                    </span>
                  </td>
                  <td className="p-4">
                    <div>
                      <p className="font-medium text-gray-800">
                        {order.customerName}
                      </p>
                      <p className="text-sm text-gray-600">
                        {order.customerEmail}
                      </p>
                    </div>
                  </td>
                  <td className="p-4">
                    <span className="text-sm text-gray-800">
                      {order.totalItems} items
                    </span>
                  </td>
                  <td className="p-4">
                    <Badge className={`${getStatusColor(order.status)} capitalize`}>
                      {order.status}
                    </Badge>
                  </td>
                  <td className="p-4">
                    <Badge className={`${getPriorityColor(order.priority)} capitalize`}>
                      {order.priority}
                    </Badge>
                  </td>
                  <td className="p-4">
                    <span className="text-sm text-gray-600">
                      {formatTimeAgo(order.createdAt)}
                    </span>
                  </td>
                  <td className="p-4">
                    <div className="flex space-x-2">
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="text-blue-600 hover:bg-blue-50"
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="text-gray-600 hover:bg-gray-100"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="p-4 border-t border-gray-200 flex items-center justify-between">
          <p className="text-sm text-gray-600">
            Showing 1-{Math.min(10, orders?.length || 0)} of {orders?.length || 0} orders
          </p>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <ChevronLeft className="w-4 h-4 mr-1" />
              Previous
            </Button>
            <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
              Next
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
