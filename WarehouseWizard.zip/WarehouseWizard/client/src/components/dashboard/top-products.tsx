import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Box, Smartphone, Laptop } from "lucide-react";
import { useTenant } from "@/contexts/tenant-context";
import { Skeleton } from "@/components/ui/skeleton";
import { Product } from "@shared/schema";

interface TopProduct {
  product: Product;
  quantity: number;
  trend: string;
}

export function TopProducts() {
  const { currentTenant } = useTenant();
  
  const { data: topProducts, isLoading } = useQuery<TopProduct[]>({
    queryKey: ["/api/dashboard/top-products", currentTenant?.id],
    enabled: !!currentTenant?.id,
  });

  const getProductIcon = (sku: string) => {
    if (sku.includes("WH")) return Box;
    if (sku.includes("SC")) return Smartphone;
    if (sku.includes("GL")) return Laptop;
    return Box;
  };

  const getIconColor = (index: number) => {
    const colors = ["bg-blue-500", "bg-green-500", "bg-orange-500"];
    return colors[index % colors.length];
  };

  if (isLoading) {
    return (
      <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
        <CardHeader>
          <CardTitle>Top Moving Products</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-gray-800">
            Top Moving Products
          </CardTitle>
          <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-700">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {topProducts?.map((item, index) => {
            const Icon = getProductIcon(item.product.sku);
            const iconColor = getIconColor(index);
            
            return (
              <div 
                key={item.product.id} 
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
              >
                <div className="flex items-center">
                  <div className={`w-12 h-12 ${iconColor} rounded-lg flex items-center justify-center mr-4`}>
                    <Icon className="text-white w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-800">
                      {item.product.name}
                    </p>
                    <p className="text-sm text-gray-600">
                      SKU: {item.product.sku}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-800">
                    {item.quantity.toLocaleString()}
                  </p>
                  <p className={`text-sm ${
                    item.trend.startsWith('+') ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {item.trend}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
