import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Package, Clock, CheckCircle, Warehouse } from "lucide-react";
import { useTenant } from "@/contexts/tenant-context";
import { Skeleton } from "@/components/ui/skeleton";

interface DashboardMetrics {
  totalInventory: number;
  pendingOrders: number;
  completedToday: number;
  warehouseCapacity: number;
}

export function MetricsGrid() {
  const { currentTenant } = useTenant();
  
  const { data: metrics, isLoading } = useQuery<DashboardMetrics>({
    queryKey: ["/api/dashboard/metrics", currentTenant?.id],
    enabled: !!currentTenant?.id,
  });

  const metricCards = [
    {
      title: "Total Inventory",
      value: metrics?.totalInventory?.toLocaleString() || "0",
      change: "+12.5%",
      changeType: "positive",
      icon: Package,
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600",
    },
    {
      title: "Pending Orders",
      value: metrics?.pendingOrders?.toString() || "0",
      change: "+5.2%",
      changeType: "negative",
      icon: Clock,
      iconBg: "bg-orange-100",
      iconColor: "text-orange-600",
    },
    {
      title: "Completed Today",
      value: metrics?.completedToday?.toString() || "0",
      change: "+18.3%",
      changeType: "positive",
      icon: CheckCircle,
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
    },
    {
      title: "Warehouse Capacity",
      value: `${metrics?.warehouseCapacity || 0}%`,
      change: "+2.1%",
      changeType: "neutral",
      icon: Warehouse,
      iconBg: "bg-purple-100",
      iconColor: "text-purple-600",
    },
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="p-6">
            <Skeleton className="h-20 w-full" />
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {metricCards.map((metric, index) => {
        const Icon = metric.icon;
        
        return (
          <Card 
            key={index} 
            className="metric-card bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-lg transition-all duration-200"
          >
            <CardContent className="p-0">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">
                    {metric.title}
                  </p>
                  <p className="text-3xl font-bold text-gray-800 mt-2">
                    {metric.value}
                  </p>
                  <div className="flex items-center mt-2">
                    <span className={`text-sm font-medium ${
                      metric.changeType === "positive" 
                        ? "text-green-600" 
                        : metric.changeType === "negative"
                        ? "text-red-600"
                        : "text-yellow-600"
                    }`}>
                      {metric.change}
                    </span>
                    <span className="text-gray-500 text-sm ml-1">
                      vs last month
                    </span>
                  </div>
                </div>
                <div className={`w-12 h-12 ${metric.iconBg} rounded-lg flex items-center justify-center`}>
                  <Icon className={`${metric.iconColor} w-6 h-6`} />
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
