import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp } from "lucide-react";

export function OrderChart() {
  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-gray-800">
            Order Trends
          </CardTitle>
          <div className="flex items-center space-x-2">
            <Button 
              size="sm" 
              variant="secondary" 
              className="bg-blue-50 text-blue-600 hover:bg-blue-100"
            >
              7 Days
            </Button>
            <Button 
              size="sm" 
              variant="ghost" 
              className="text-gray-600 hover:bg-gray-100"
            >
              30 Days
            </Button>
            <Button 
              size="sm" 
              variant="ghost" 
              className="text-gray-600 hover:bg-gray-100"
            >
              90 Days
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="chart-container h-64 rounded-lg flex items-center justify-center text-white">
          <div className="text-center">
            <TrendingUp className="w-16 h-16 mb-4 opacity-75 mx-auto" />
            <p className="text-lg font-medium">Interactive Order Trends Chart</p>
            <p className="text-sm opacity-75 mt-1">Chart.js implementation required</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
